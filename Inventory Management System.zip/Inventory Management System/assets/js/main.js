/**
 * Main Application Bootstrap
 * Inventory Management System
 * 
 * This file initializes the application and handles global setup.
 */

(function () {
    'use strict';

    /**
     * Application initialization
     */
    async function initApp() {
        console.log('Initializing Inventory Management System...');

        // Check if Firebase is loaded and configured
        if (!window.FirebaseConfig || !window.FirebaseConfig.isConfigured()) {
            console.log('Firebase not configured yet, waiting for configuration...');
            return;
        }

        // Set up mobile menu toggle
        setupMobileMenu();

        // Set up logout buttons
        setupLogoutButtons();

        // Set up active navigation highlighting
        highlightActiveNav();

        console.log('Application initialized successfully');
    }

    /**
     * Setup mobile menu toggle functionality
     */
    function setupMobileMenu() {
        const menuToggle = document.querySelector('.menu-toggle');
        const sidebar = document.querySelector('.sidebar');

        if (menuToggle && sidebar) {
            menuToggle.addEventListener('click', () => {
                sidebar.classList.toggle('open');
            });

            // Close sidebar when clicking outside
            document.addEventListener('click', (e) => {
                if (sidebar.classList.contains('open') &&
                    !sidebar.contains(e.target) &&
                    !menuToggle.contains(e.target)) {
                    sidebar.classList.remove('open');
                }
            });
        }
    }

    /**
     * Setup logout button handlers
     */
    function setupLogoutButtons() {
        const logoutButtons = document.querySelectorAll('[data-action="logout"]');

        logoutButtons.forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.preventDefault();

                if (window.Auth && typeof window.Auth.logout === 'function') {
                    await window.Auth.logout();
                } else {
                    // Fallback direct logout
                    try {
                        await firebase.auth().signOut();
                        window.location.href = '/login.html';
                    } catch (error) {
                        console.error('Logout error:', error);
                    }
                }
            });
        });
    }

    /**
     * Highlight active navigation item based on current page
     */
    function highlightActiveNav() {
        const currentPath = window.location.pathname;
        const navLinks = document.querySelectorAll('.sidebar-link, .nav-item');

        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href) {
                // Handle both relative and absolute paths for matching
                const filename = href.split('/').pop();
                if (currentPath.endsWith(filename)) {
                    link.classList.add('active');
                } else {
                    link.classList.remove('active');
                }
            }
        });
    }

    /**
     * Update user info in sidebar
     * @param {Object} user - User object with name and role
     */
    function updateUserInfo(user) {
        const userNameEl = document.querySelector('.user-name');
        const userRoleEl = document.querySelector('.user-role');
        const userAvatarEl = document.querySelector('.user-avatar');

        if (userNameEl && user.name) {
            userNameEl.textContent = user.name;
        }

        if (userRoleEl && user.role) {
            const roleLabels = window.APP_CONSTANTS?.ROLE_LABELS || {};
            userRoleEl.textContent = roleLabels[user.role] || user.role;
        }

        if (userAvatarEl && user.name) {
            userAvatarEl.textContent = window.Utils?.getInitials(user.name) || user.name[0];
        }
    }

    /**
     * Check if running on mobile device
     * @returns {boolean}
     */
    function isMobile() {
        return window.innerWidth <= 768;
    }

    /**
     * Get current page name
     * @returns {string}
     */
    function getCurrentPage() {
        const path = window.location.pathname;
        const parts = path.split('/');
        return parts[parts.length - 1].replace('.html', '');
    }

    // Initialize when DOM is ready
    document.addEventListener('DOMContentLoaded', initApp);

    // Export functions globally
    window.App = {
        init: initApp,
        updateUserInfo,
        isMobile,
        getCurrentPage
    };
})();
