/**
 * Firebase Configuration
 * Inventory Management System
 * 
 * IMPORTANT: Replace the placeholder values below with your actual Firebase project configuration.
 * You can find these values in your Firebase Console:
 * 1. Go to https://console.firebase.google.com
 * 2. Select your project (or create a new one)
 * 3. Click the gear icon (Settings) > Project settings
 * 4. Scroll down to "Your apps" section
 * 5. If no app exists, click "Add app" and select Web (</>)
 * 6. Copy the firebaseConfig object values
 */

// Firebase configuration object
const firebaseConfig = {
    apiKey: "AIzaSyDkA5HVFQPH7nPibMTlWF5gFuSnR9-TJzQ",
    authDomain: "inventory-management-sys-2aa8b.firebaseapp.com",
    projectId: "inventory-management-sys-2aa8b",
    storageBucket: "inventory-management-sys-2aa8b.firebasestorage.app",
    messagingSenderId: "877392379216",
    appId: "1:877392379216:web:49653eab1e27d538bc0055"
};

// Initialize Firebase
let app = null;
let auth = null;
let db = null;

/**
 * Initialize Firebase services
 * @returns {boolean} True if initialization successful, false otherwise
 */
function initializeFirebase() {
    try {
        // Check if Firebase SDK is loaded
        if (typeof firebase === 'undefined') {
            console.error('Firebase SDK not loaded. Make sure to include Firebase scripts in your HTML.');
            return false;
        }

        // Check if already initialized
        if (firebase.apps.length > 0) {
            app = firebase.apps[0];
        } else {
            // Validate configuration
            if (firebaseConfig.apiKey === "YOUR_API_KEY") {
                console.error('Firebase not configured. Please update firebase-config.js with your project credentials.');
                showConfigurationError();
                return false;
            }

            // Initialize Firebase app
            app = firebase.initializeApp(firebaseConfig);
        }

        // Initialize Auth
        auth = firebase.auth();

        // Initialize Firestore
        db = firebase.firestore();

        // Enable Firestore offline persistence (optional, enhances UX)
        db.enablePersistence({ synchronizeTabs: true })
            .catch((err) => {
                if (err.code === 'failed-precondition') {
                    console.warn('Firestore persistence failed: Multiple tabs open');
                } else if (err.code === 'unimplemented') {
                    console.warn('Firestore persistence not supported in this browser');
                }
            });

        console.log('Firebase initialized successfully');
        return true;
    } catch (error) {
        console.error('Firebase initialization error:', error);
        showConfigurationError();
        return false;
    }
}

/**
 * Display configuration error message on the page
 */
function showConfigurationError() {
    const errorContainer = document.createElement('div');
    errorContainer.id = 'firebase-error';
    errorContainer.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #FEE2E2;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 20px;
        z-index: 9999;
        font-family: Arial, sans-serif;
    `;
    errorContainer.innerHTML = `
        <h1 style="color: #991B1B; margin-bottom: 16px;">Firebase Configuration Required</h1>
        <p style="color: #991B1B; max-width: 600px; text-align: center; margin-bottom: 24px;">
            The application is not configured with Firebase credentials. 
            Please update the <code style="background: #FECACA; padding: 2px 6px; border-radius: 4px;">assets/js/firebase/firebase-config.js</code> 
            file with your Firebase project configuration.
        </p>
        <div style="background: white; padding: 16px; border-radius: 8px; max-width: 600px; width: 100%;">
            <p style="margin-bottom: 8px; font-weight: bold;">Steps to configure:</p>
            <ol style="text-align: left; line-height: 1.8;">
                <li>Go to <a href="https://console.firebase.google.com" target="_blank">Firebase Console</a></li>
                <li>Create a new project or select existing one</li>
                <li>Go to Project Settings > General</li>
                <li>Scroll to "Your apps" and add a Web app</li>
                <li>Copy the configuration values</li>
                <li>Update firebase-config.js with your values</li>
                <li>Enable Authentication (Email/Password) in Firebase Console</li>
                <li>Create Firestore Database in Firebase Console</li>
            </ol>
        </div>
    `;
    document.body.innerHTML = '';
    document.body.appendChild(errorContainer);
}

/**
 * Get Firestore database instance
 * @returns {firebase.firestore.Firestore|null}
 */
function getDb() {
    return db;
}

/**
 * Get Firebase Auth instance
 * @returns {firebase.auth.Auth|null}
 */
function getAuth() {
    return auth;
}

/**
 * Check if Firebase is properly configured
 * @returns {boolean}
 */
function isFirebaseConfigured() {
    return firebaseConfig.apiKey !== "YOUR_API_KEY" && app !== null;
}

// Initialize Firebase when script loads
document.addEventListener('DOMContentLoaded', () => {
    initializeFirebase();
});

// Make functions available globally (for non-module usage)
window.FirebaseConfig = {
    init: initializeFirebase,
    getDb: getDb,
    getAuth: getAuth,
    isConfigured: isFirebaseConfigured
};
