/**
 * Authentication Module
 * Inventory Management System
 * 
 * Handles user authentication: login, logout, registration, and session management.
 */

(function () {
    'use strict';

    const { COLLECTIONS, ERROR_MESSAGES, SUCCESS_MESSAGES, DEFAULT_REDIRECTS, ROLES } = window.APP_CONSTANTS || {};

    /**
     * Get base path based on current location
     * Returns '.' for root, '..' for one level deep, etc.
     */
    function getBasePath() {
        const path = window.location.pathname;
        if (path.includes('/admin/') || path.includes('/staff/')) {
            return '..';
        }
        return '.';
    }

    /**
     * Register a new user
     * @param {string} name - User's full name
     * @param {string} email - User's email
     * @param {string} password - User's password
     * @param {string} role - User role (ADMIN, STAFF, CUSTOMER)
     * @returns {Promise<{success: boolean, user?: Object, error?: string}>}
     */
    async function register(name, email, password, role) {
        try {
            const auth = firebase.auth();
            const db = firebase.firestore();

            // Create user in Firebase Auth
            const userCredential = await auth.createUserWithEmailAndPassword(email, password);
            const user = userCredential.user;

            // Create user document in Firestore
            const userData = {
                uid: user.uid,
                name: name,
                email: email,
                role: role || ROLES.STAFF,
                active: true,
                createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            };

            await db.collection(COLLECTIONS.USERS).doc(user.uid).set(userData);

            console.log('User registered successfully:', user.uid);

            // Redirect based on role
            setTimeout(() => {
                const redirectPath = DEFAULT_REDIRECTS[role] || DEFAULT_REDIRECTS.STAFF;
                window.location.href = getBasePath() + redirectPath;
            }, 1000);

            return {
                success: true,
                user: { ...userData, id: user.uid }
            };
        } catch (error) {
            console.error('Registration error:', error);

            let errorMessage = ERROR_MESSAGES.GENERIC_ERROR;

            switch (error.code) {
                case 'auth/email-already-in-use':
                    errorMessage = ERROR_MESSAGES.AUTH_EMAIL_IN_USE;
                    break;
                case 'auth/weak-password':
                    errorMessage = ERROR_MESSAGES.AUTH_WEAK_PASSWORD;
                    break;
                case 'auth/invalid-email':
                    errorMessage = 'Please enter a valid email address.';
                    break;
                case 'auth/network-request-failed':
                    errorMessage = ERROR_MESSAGES.NETWORK_ERROR;
                    break;
            }

            return { success: false, error: errorMessage };
        }
    }

    /**
     * Login user with email and password
     * @param {string} email - User's email
     * @param {string} password - User's password
     * @returns {Promise<{success: boolean, user?: Object, error?: string}>}
     */
    async function login(email, password) {
        try {
            const auth = firebase.auth();
            const db = firebase.firestore();

            // Sign in with Firebase Auth
            const userCredential = await auth.signInWithEmailAndPassword(email, password);
            const user = userCredential.user;

            // Fetch user data from Firestore
            const userDoc = await db.collection(COLLECTIONS.USERS).doc(user.uid).get();

            if (!userDoc.exists) {
                // User exists in Auth but not in Firestore - create document
                console.warn('User document not found, creating one...');
                const userData = {
                    uid: user.uid,
                    name: user.displayName || email.split('@')[0],
                    email: email,
                    role: ROLES.STAFF, // Default role
                    active: true,
                    createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                    updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                };
                await db.collection(COLLECTIONS.USERS).doc(user.uid).set(userData);

                setTimeout(() => {
                    window.location.href = getBasePath() + DEFAULT_REDIRECTS.STAFF;
                }, 1000);

                return { success: true, user: { ...userData, id: user.uid } };
            }

            const userData = userDoc.data();

            // Check if user is active
            if (!userData.active) {
                await auth.signOut();
                return { success: false, error: 'Your account has been disabled. Please contact admin.' };
            }

            console.log('User logged in successfully:', user.uid, 'Role:', userData.role);

            // Redirect based on role
            setTimeout(() => {
                const redirectPath = DEFAULT_REDIRECTS[userData.role] || DEFAULT_REDIRECTS.STAFF;
                window.location.href = getBasePath() + redirectPath;
            }, 1000);

            return {
                success: true,
                user: { id: user.uid, ...userData }
            };
        } catch (error) {
            console.error('Login error:', error);

            let errorMessage = ERROR_MESSAGES.GENERIC_ERROR;

            switch (error.code) {
                case 'auth/user-not-found':
                    errorMessage = ERROR_MESSAGES.AUTH_USER_NOT_FOUND;
                    break;
                case 'auth/wrong-password':
                    errorMessage = ERROR_MESSAGES.AUTH_WRONG_PASSWORD;
                    break;
                case 'auth/invalid-email':
                    errorMessage = 'Please enter a valid email address.';
                    break;
                case 'auth/too-many-requests':
                    errorMessage = 'Too many failed attempts. Please try again later.';
                    break;
                case 'auth/network-request-failed':
                    errorMessage = ERROR_MESSAGES.NETWORK_ERROR;
                    break;
                case 'auth/invalid-credential':
                    errorMessage = ERROR_MESSAGES.AUTH_INVALID_CREDENTIALS;
                    break;
            }

            return { success: false, error: errorMessage };
        }
    }

    /**
     * Logout current user
     * @returns {Promise<{success: boolean, error?: string}>}
     */
    async function logout() {
        try {
            await firebase.auth().signOut();
            console.log('User logged out successfully');

            // Redirect to login page
            window.location.href = getBasePath() + '/login.html';

            return { success: true };
        } catch (error) {
            console.error('Logout error:', error);
            return { success: false, error: ERROR_MESSAGES.GENERIC_ERROR };
        }
    }

    /**
     * Get current authenticated user with Firestore data
     * @returns {Promise<Object|null>}
     */
    async function getCurrentUser() {
        return new Promise((resolve) => {
            const unsubscribe = firebase.auth().onAuthStateChanged(async (user) => {
                unsubscribe();

                if (!user) {
                    resolve(null);
                    return;
                }

                try {
                    const db = firebase.firestore();
                    const userDoc = await db.collection(COLLECTIONS.USERS).doc(user.uid).get();

                    if (!userDoc.exists) {
                        resolve(null);
                        return;
                    }

                    resolve({ id: user.uid, ...userDoc.data() });
                } catch (error) {
                    console.error('Error fetching user data:', error);
                    resolve(null);
                }
            });
        });
    }

    /**
     * Listen to auth state changes
     * @param {Function} callback - Callback function receiving user object or null
     * @returns {Function} Unsubscribe function
     */
    function onAuthStateChanged(callback) {
        return firebase.auth().onAuthStateChanged(async (user) => {
            if (!user) {
                callback(null);
                return;
            }

            try {
                const db = firebase.firestore();
                const userDoc = await db.collection(COLLECTIONS.USERS).doc(user.uid).get();

                if (!userDoc.exists) {
                    callback(null);
                    return;
                }

                callback({ id: user.uid, ...userDoc.data() });
            } catch (error) {
                console.error('Error in auth state change:', error);
                callback(null);
            }
        });
    }

    /**
     * Update user profile
     * @param {string} userId - User ID
     * @param {Object} updates - Fields to update
     * @returns {Promise<{success: boolean, error?: string}>}
     */
    async function updateUserProfile(userId, updates) {
        try {
            const db = firebase.firestore();

            await db.collection(COLLECTIONS.USERS).doc(userId).update({
                ...updates,
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            return { success: true };
        } catch (error) {
            console.error('Error updating user profile:', error);
            return { success: false, error: ERROR_MESSAGES.GENERIC_ERROR };
        }
    }

    /**
     * Change user password
     * @param {string} currentPassword - Current password
     * @param {string} newPassword - New password
     * @returns {Promise<{success: boolean, error?: string}>}
     */
    async function changePassword(currentPassword, newPassword) {
        try {
            const user = firebase.auth().currentUser;

            if (!user) {
                return { success: false, error: 'No user logged in.' };
            }

            // Re-authenticate user
            const credential = firebase.auth.EmailAuthProvider.credential(
                user.email,
                currentPassword
            );

            await user.reauthenticateWithCredential(credential);

            // Update password
            await user.updatePassword(newPassword);

            return { success: true };
        } catch (error) {
            console.error('Error changing password:', error);

            let errorMessage = ERROR_MESSAGES.GENERIC_ERROR;

            if (error.code === 'auth/wrong-password') {
                errorMessage = 'Current password is incorrect.';
            }

            return { success: false, error: errorMessage };
        }
    }

    // Export functions globally
    window.Auth = {
        register,
        login,
        logout,
        getCurrentUser,
        onAuthStateChanged,
        updateUserProfile,
        changePassword
    };
})();
