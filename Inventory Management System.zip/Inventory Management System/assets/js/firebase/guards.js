/**
 * Route Guards
 * Inventory Management System
 * 
 * Handles route protection and role-based access control.
 */

(function () {
    'use strict';

    const { ROUTES, ROUTE_ACCESS, ROLES, ERROR_MESSAGES } = window.APP_CONSTANTS || {};

    // Flag to prevent multiple redirects
    let isRedirecting = false;

    // Auth state loaded flag
    let authStateLoaded = false;

    /**
     * Get current page path
     * @returns {string}
     */
    function getCurrentPath() {
        const path = window.location.pathname;
        // Normalize path
        if (path.endsWith('/')) {
            return path + 'index.html';
        }
        return path;
    }

    /**
     * Check if current page is a public page (no auth required)
     * @returns {boolean}
     */
    function isPublicPage() {
        const path = getCurrentPath();
        const publicPages = ['/index.html', '/login.html', '/register.html'];
        return publicPages.some(p => path.endsWith(p));
    }

    /**
     * Check if user has access to current page based on role
     * @param {string} role - User's role
     * @returns {boolean}
     */
    function hasAccess(role) {
        const path = getCurrentPath();

        // Check route access rules
        for (const [route, allowedRoles] of Object.entries(ROUTE_ACCESS || {})) {
            if (path.endsWith(route)) {
                return allowedRoles.includes(role);
            }
        }

        // If no specific rule, check general patterns
        if (path.includes('/admin/')) {
            return role === ROLES.ADMIN;
        }

        if (path.includes('/staff/')) {
            return role === ROLES.ADMIN || role === ROLES.STAFF;
        }

        if (path.includes('/customer/')) {
            return true; // All authenticated users can access customer pages
        }

        return true; // Default allow
    }

    /**
     * Get base path based on current location
     */
    function getBasePath() {
        const path = window.location.pathname;
        if (path.includes('/admin/') || path.includes('/staff/') || path.includes('/customer/')) {
            return '..';
        }
        return '.';
    }

    /**
     * Redirect to login page
     */
    function redirectToLogin() {
        if (isRedirecting) return;
        isRedirecting = true;
        window.location.href = getBasePath() + '/login.html';
    }

    /**
     * Redirect to appropriate dashboard based on role
     * @param {string} role - User's role
     */
    function redirectToDashboard(role) {
        if (isRedirecting) return;
        isRedirecting = true;

        const redirects = {
            [ROLES.ADMIN]: '/admin/dashboard.html',
            [ROLES.STAFF]: '/staff/billing.html',
            [ROLES.CUSTOMER]: '/customer/profile.html'
        };

        window.location.href = getBasePath() + (redirects[role] || redirects[ROLES.STAFF]);
    }

    /**
     * Show unauthorized message
     */
    function showUnauthorized() {
        const messageHtml = `
            <div style="
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: #FEF3C7;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                padding: 20px;
                z-index: 9999;
                font-family: Arial, sans-serif;
            ">
                <h1 style="color: #92400E; margin-bottom: 16px;">Access Denied</h1>
                <p style="color: #92400E; margin-bottom: 24px;">
                    You do not have permission to access this page.
                </p>
                <button onclick="window.history.back()" style="
                    padding: 12px 24px;
                    background-color: #0EA5E9;
                    color: white;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;
                    margin-right: 8px;
                ">Go Back</button>
                <button onclick="window.Auth && window.Auth.logout()" style="
                    padding: 12px 24px;
                    background-color: white;
                    color: #0EA5E9;
                    border: 1px solid #0EA5E9;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;
                    margin-top: 8px;
                ">Logout</button>
            </div>
        `;

        document.body.innerHTML = messageHtml;
    }

    /**
     * Initialize route protection
     * This should be called on every protected page
     */
    function initGuard() {
        // Skip for public pages
        if (isPublicPage()) {
            return;
        }

        // Show loading state
        document.body.style.visibility = 'hidden';

        // Wait for Firebase to be ready
        const checkFirebase = setInterval(() => {
            if (typeof firebase !== 'undefined' && firebase.auth) {
                clearInterval(checkFirebase);
                setupAuthListener();
            }
        }, 100);

        // Timeout after 5 seconds
        setTimeout(() => {
            clearInterval(checkFirebase);
            if (!authStateLoaded) {
                console.error('Firebase auth timeout');
                redirectToLogin();
            }
        }, 5000);
    }

    /**
     * Setup auth state listener for route protection
     */
    function setupAuthListener() {
        firebase.auth().onAuthStateChanged(async (user) => {
            authStateLoaded = true;

            if (!user) {
                // Not authenticated
                console.log('User not authenticated, redirecting to login...');
                redirectToLogin();
                return;
            }

            try {
                // Get user role from Firestore
                const db = firebase.firestore();
                const userDoc = await db.collection('users').doc(user.uid).get();

                if (!userDoc.exists) {
                    console.error('User document not found');
                    redirectToLogin();
                    return;
                }

                const userData = userDoc.data();
                const role = userData.role;

                // Check if user has access to current page
                if (!hasAccess(role)) {
                    console.log('User does not have access to this page');
                    showUnauthorized();
                    return;
                }

                // Check if user is active
                if (!userData.active) {
                    console.log('User account is disabled');
                    await firebase.auth().signOut();
                    redirectToLogin();
                    return;
                }

                // User has access, show page
                document.body.style.visibility = 'visible';

                // Initialize sidebar with user role
                if (window.Sidebar && window.Sidebar.init) {
                    window.Sidebar.init(userData);
                }

                // Update user info in UI if App is available
                if (window.App && window.App.updateUserInfo) {
                    window.App.updateUserInfo(userData);
                }

            } catch (error) {
                console.error('Error checking user access:', error);
                redirectToLogin();
            }
        });
    }

    /**
     * Require authentication for current page
     * @param {string[]} allowedRoles - Optional array of allowed roles
     * @returns {Promise<Object|null>} User object if authorized, null otherwise
     */
    async function requireAuth(allowedRoles = null) {
        return new Promise((resolve) => {
            if (typeof firebase === 'undefined' || !firebase.auth) {
                console.error('Firebase not loaded');
                resolve(null);
                return;
            }

            const unsubscribe = firebase.auth().onAuthStateChanged(async (user) => {
                unsubscribe();

                if (!user) {
                    redirectToLogin();
                    resolve(null);
                    return;
                }

                try {
                    const db = firebase.firestore();
                    const userDoc = await db.collection('users').doc(user.uid).get();

                    if (!userDoc.exists) {
                        redirectToLogin();
                        resolve(null);
                        return;
                    }

                    const userData = { id: user.uid, ...userDoc.data() };

                    // Check role if specified
                    if (allowedRoles && !allowedRoles.includes(userData.role)) {
                        showUnauthorized();
                        resolve(null);
                        return;
                    }

                    // Check if active
                    if (!userData.active) {
                        await firebase.auth().signOut();
                        redirectToLogin();
                        resolve(null);
                        return;
                    }

                    resolve(userData);
                } catch (error) {
                    console.error('Error in requireAuth:', error);
                    resolve(null);
                }
            });
        });
    }

    /**
     * Require admin role
     * @returns {Promise<Object|null>}
     */
    async function requireAdmin() {
        return requireAuth([ROLES.ADMIN]);
    }

    /**
     * Require staff or admin role
     * @returns {Promise<Object|null>}
     */
    async function requireStaff() {
        return requireAuth([ROLES.ADMIN, ROLES.STAFF]);
    }

    // Auto-initialize guard when DOM is ready
    document.addEventListener('DOMContentLoaded', () => {
        // Only init guard if not on public page
        if (!isPublicPage()) {
            initGuard();
        }
    });

    // Export functions globally
    window.Guards = {
        initGuard,
        requireAuth,
        requireAdmin,
        requireStaff,
        hasAccess,
        isPublicPage,
        redirectToLogin,
        redirectToDashboard
    };
})();
