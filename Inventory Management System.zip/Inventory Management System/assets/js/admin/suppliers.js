/**
 * Supplier Management
 * Inventory Management System
 * 
 * CRUD operations for managing suppliers.
 */

(function () {
    'use strict';

    const { COLLECTIONS } = window.APP_CONSTANTS || {};

    let db = null;
    let currentUser = null;
    let allSuppliers = [];
    let productCounts = {};

    // History modal state
    let selectedSupplierId = null;
    let selectedSupplierName = null;

    const elements = {};

    async function init() {
        currentUser = await window.Guards.requireAdmin();
        if (!currentUser) return;

        window.App?.updateUserInfo?.(currentUser);
        window.Sidebar?.update?.(currentUser.role);

        db = firebase.firestore();

        cacheElements();
        setupEventListeners();
        await loadSuppliers();
    }

    function cacheElements() {
        elements.searchInput = document.getElementById('search-input');
        elements.suppliersBody = document.getElementById('suppliers-body');
        elements.addSupplierBtn = document.getElementById('add-supplier-btn');
        elements.supplierModal = document.getElementById('supplier-modal');
        elements.modalTitle = document.getElementById('modal-title');
        elements.supplierForm = document.getElementById('supplier-form');
        elements.modalClose = document.getElementById('modal-close');
        elements.cancelBtn = document.getElementById('cancel-btn');
        elements.saveBtn = document.getElementById('save-btn');
        elements.supplierId = document.getElementById('supplier-id');
        elements.supplierName = document.getElementById('supplier-name');
        elements.supplierPhone = document.getElementById('supplier-phone');
        elements.supplierEmail = document.getElementById('supplier-email');
        elements.supplierGst = document.getElementById('supplier-gst');
        elements.supplierAddress = document.getElementById('supplier-address');

        elements.viewModal = document.getElementById('supplier-products-modal');
        elements.viewBody = document.getElementById('supplier-products-body');
        elements.viewTitle = document.getElementById('view-supplier-name');
        elements.closeViewBtn = document.getElementById('close-view-btn');
        elements.closeViewX = document.getElementById('close-view-modal');

        elements.fromDate = document.getElementById('history-from-date');
        elements.toDate = document.getElementById('history-to-date');
        elements.loadHistoryBtn = document.getElementById('load-history-btn');
    }

    function setupEventListeners() {
        elements.searchInput.addEventListener('input', Utils.debounce(filterSuppliers, 300));
        elements.addSupplierBtn.addEventListener('click', () => openModal());
        elements.modalClose.addEventListener('click', closeModal);
        elements.cancelBtn.addEventListener('click', closeModal);
        elements.supplierModal.addEventListener('click', e => {
            if (e.target === elements.supplierModal) closeModal();
        });
        elements.supplierForm.addEventListener('submit', handleFormSubmit);

        // History modal
        elements.loadHistoryBtn.addEventListener('click', loadSupplierHistory);
        elements.closeViewBtn.addEventListener('click', closeHistoryModal);
        elements.closeViewX.addEventListener('click', closeHistoryModal);
        elements.viewModal.addEventListener('click', e => {
            if (e.target === elements.viewModal) closeHistoryModal();
        });
    }

    async function loadSuppliers() {
        elements.suppliersBody.innerHTML =
            '<tr><td colspan="6" class="text-center">Loading suppliers...</td></tr>';

        const snap = await db.collection(COLLECTIONS.SUPPLIERS)
            .where('active', '==', true)
            .get();

        if (snap.empty) {
            elements.suppliersBody.innerHTML =
                '<tr><td colspan="6" class="text-center">No suppliers found.</td></tr>';
            return;
        }

        allSuppliers = [];
        snap.forEach(doc => allSuppliers.push({ id: doc.id, ...doc.data() }));

        allSuppliers.sort((a, b) =>
            (a.name || '').toLowerCase().localeCompare((b.name || '').toLowerCase())
        );

        await loadProductCounts();
        renderSuppliers(allSuppliers);
    }

    async function loadProductCounts() {
        const snap = await db.collection(COLLECTIONS.PRODUCTS)
            .where('active', '==', true)
            .get();

        productCounts = {};
        snap.forEach(doc => {
            const d = doc.data();
            if (d.supplierId) {
                productCounts[d.supplierId] =
                    (productCounts[d.supplierId] || 0) + 1;
            }
        });
    }

    function renderSuppliers(suppliers) {
        elements.suppliersBody.innerHTML = suppliers.map(s => `
            <tr>
                <td>${Utils.sanitize(s.name || '-')}</td>
                <td>${Utils.sanitize(s.phone || '-')}</td>
                <td>${Utils.sanitize(s.email || '-')}</td>
                <td>${Utils.sanitize(s.gstNumber || '-')}</td>
                <td><span class="badge badge-info">${productCounts[s.id] || 0}</span></td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn-sm btn-primary"
                            onclick="Suppliers.viewProducts('${s.id}', '${Utils.sanitize(s.name)}')">
                            History
                        </button>
                        <button class="btn btn-sm btn-secondary"
                            onclick="Suppliers.editSupplier('${s.id}')">Edit</button>
                        <button class="btn btn-sm btn-outline"
                            onclick="Suppliers.deleteSupplier('${s.id}')">Delete</button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    function filterSuppliers() {
        const t = elements.searchInput.value.toLowerCase();
        renderSuppliers(!t ? allSuppliers : allSuppliers.filter(s =>
            (s.name || '').toLowerCase().includes(t) ||
            (s.phone || '').toLowerCase().includes(t) ||
            (s.email || '').toLowerCase().includes(t)
        ));
    }

    function openModal(supplier = null) {
        if (supplier) {
            elements.modalTitle.textContent = 'Edit Supplier';
            elements.supplierId.value = supplier.id;
            elements.supplierName.value = supplier.name || '';
            elements.supplierPhone.value = supplier.phone || '';
            elements.supplierEmail.value = supplier.email || '';
            elements.supplierGst.value = supplier.gstNumber || '';
            elements.supplierAddress.value = supplier.address || '';
        } else {
            elements.modalTitle.textContent = 'Add Supplier';
            elements.supplierForm.reset();
            elements.supplierId.value = '';
        }
        elements.supplierModal.classList.add('active');
    }

    function closeModal() {
        elements.supplierModal.classList.remove('active');
        elements.supplierForm.reset();
    }

    function closeHistoryModal() {
        elements.viewModal.classList.remove('active');
        elements.viewBody.innerHTML = '';
        selectedSupplierId = null;
        selectedSupplierName = null;
    }

    async function handleFormSubmit(e) {
        e.preventDefault();
        const supplierId = elements.supplierId.value;

        const data = {
            name: elements.supplierName.value.trim(),
            phone: elements.supplierPhone.value.trim(),
            email: elements.supplierEmail.value.trim(),
            gstNumber: elements.supplierGst.value.trim(),
            address: elements.supplierAddress.value.trim(),
            active: true,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        };

        supplierId
            ? await db.collection(COLLECTIONS.SUPPLIERS).doc(supplierId).update(data)
            : await db.collection(COLLECTIONS.SUPPLIERS).add({
                ...data,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });

        closeModal();
        await loadSuppliers();
    }

    async function editSupplier(id) {
        const s = allSuppliers.find(x => x.id === id);
        if (s) openModal(s);
    }

    async function deleteSupplier(id) {
        if (!await Utils.showConfirm('Delete supplier?', 'Delete', 'Cancel')) return;
        await db.collection(COLLECTIONS.SUPPLIERS).doc(id).update({ active: false });
        await loadSuppliers();
    }

    function viewProducts(id, name) {
        selectedSupplierId = id;
        selectedSupplierName = name;

        elements.viewTitle.textContent = `Purchase History: ${name}`;
        elements.viewBody.innerHTML =
            '<tr><td colspan="6" class="text-center">Select date range and click Load History</td></tr>';
        elements.viewModal.classList.add('active');
    }

    async function loadSupplierHistory() {
        if (!selectedSupplierId) return;

        const from = elements.fromDate.value;
        const to = elements.toDate.value;
        if (!from || !to) return Utils.showToast('Select both dates', 'warning');

        const fromDate = new Date(from);
        const toDate = new Date(to);
        toDate.setHours(23, 59, 59, 999);

        elements.viewBody.innerHTML =
            '<tr><td colspan="6" class="text-center">Loading...</td></tr>';

        const productsSnap = await db.collection(COLLECTIONS.PRODUCTS)
            .where('supplierId', '==', selectedSupplierId)
            .get();

        const productMap = {};
        productsSnap.forEach(d => productMap[d.id] = d.data());

        const logsSnap = await db.collection(COLLECTIONS.INVENTORY_LOGS)
            .where('change', '>', 0)
            .get();

        let html = '';

        logsSnap.forEach(doc => {
            const log = doc.data();
            if (!log.createdAt) return;

            const date = log.createdAt.toDate();
            if (date < fromDate || date > toDate) return;

            const p = productMap[log.productId];
            if (!p) return;

            const value = (p.buyingPrice || 0) * log.change;

            html += `
                <tr>
                    <td>${Utils.sanitize(p.name)}</td>
                    <td>${log.change}</td>
                    <td>${Utils.formatCurrency(p.buyingPrice || 0)}</td>
                    <td>${Utils.formatCurrency(value)}</td>
                    <td>${log.reason || '-'}</td>
                    <td>${Utils.formatDate(log.createdAt)}</td>
                </tr>
            `;
        });

        elements.viewBody.innerHTML = html ||
            '<tr><td colspan="6" class="text-center">No history found</td></tr>';
    }

    document.addEventListener('DOMContentLoaded', init);

    window.Suppliers = {
        init,
        editSupplier,
        deleteSupplier,
        viewProducts
    };

})();
