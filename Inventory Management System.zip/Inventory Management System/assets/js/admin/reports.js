/**
 * Reports Module
 * Inventory Management System
 */

(function () {
    'use strict';

    const { COLLECTIONS, DEFAULT_SETTINGS } = window.APP_CONSTANTS || {};

    let db = null;
    let currentUser = null;
    let settings = DEFAULT_SETTINGS;
    let currentTab = 'sales';

    const elements = {};
    const reportData = { sales: [], inventory: [], customers: [] };

    /* ================= INIT ================= */

    async function init() {
        currentUser = await window.Guards.requireAdmin();
        if (!currentUser) return;

        if (window.App?.updateUserInfo) {
            window.App.updateUserInfo(currentUser);
        }

        db = firebase.firestore();

        cacheElements();
        setupEventListeners();
        setDefaultDates();
        await loadSettings();
    }

    function cacheElements() {
        elements.tabBtns = document.querySelectorAll('.tab-btn');
        elements.dateFrom = document.getElementById('date-from');
        elements.dateTo = document.getElementById('date-to');
        elements.paymentFilter = document.getElementById('payment-filter');
        elements.paymentFilterGroup = document.getElementById('payment-filter-group');
        elements.generateBtn = document.getElementById('generate-btn');
        elements.exportBtn = document.getElementById('export-btn');

        // Sales Elements
        elements.totalSales = document.getElementById('total-sales');
        elements.totalBills = document.getElementById('total-bills');
        elements.avgBill = document.getElementById('avg-bill');
        elements.totalTax = document.getElementById('total-tax');
        elements.totalProfit = document.getElementById('total-profit');
        elements.salesTable = document.getElementById('sales-table');

        // Inventory Elements
        elements.invTotalProducts = document.getElementById('inv-total-products');
        elements.invLowStock = document.getElementById('inv-low-stock');
        elements.invOutStock = document.getElementById('inv-out-stock');
        elements.invStockValue = document.getElementById('inv-stock-value');
        elements.inventoryTable = document.getElementById('inventory-report-table');

        // Customer Elements
        elements.custTotal = document.getElementById('cust-total');
        elements.custActive = document.getElementById('cust-active');
        elements.custRevenue = document.getElementById('cust-revenue');
        elements.custDues = document.getElementById('cust-dues');
        elements.customersTable = document.getElementById('customers-report-table');
    }

    function setupEventListeners() {
        elements.tabBtns.forEach(btn =>
            btn.addEventListener('click', () => switchTab(btn.dataset.tab))
        );

        elements.generateBtn.addEventListener('click', generateReport);
        elements.exportBtn.addEventListener('click', exportCSV);
    }

    function setDefaultDates() {
        const today = new Date();
        const first = new Date(today.getFullYear(), today.getMonth(), 1);
        elements.dateFrom.value = first.toISOString().split('T')[0];
        elements.dateTo.value = today.toISOString().split('T')[0];
    }

    async function loadSettings() {
        const doc = await db.collection(COLLECTIONS.SETTINGS).doc('config').get();
        if (doc.exists) settings = { ...DEFAULT_SETTINGS, ...doc.data() };
    }

    function switchTab(tab) {
        currentTab = tab;
        elements.tabBtns.forEach(b => b.classList.remove('active'));
        document.querySelector(`[data-tab="${tab}"]`).classList.add('active');

        document.querySelectorAll('.tab-content').forEach(t => {
            t.style.display = 'none';
            t.classList.remove('active');
        });

        const activeTab = document.getElementById(`${tab}-tab`);
        if (activeTab) {
            activeTab.style.display = 'block';
            activeTab.classList.add('active');
        }

        if (elements.paymentFilterGroup) {
            elements.paymentFilterGroup.style.display = tab === 'sales' ? 'block' : 'none';
        }
    }

    async function generateReport() {
        elements.generateBtn.disabled = true;
        const originalBtnText = elements.generateBtn.textContent;
        elements.generateBtn.textContent = 'Processing...';

        try {
            if (currentTab === 'sales') await generateSalesReport();
            else if (currentTab === 'inventory') await generateInventoryReport();
            else if (currentTab === 'customers') await generateCustomerReport();
        } catch (error) {
            console.error('Report Error:', error);
            Utils.showToast('Failed to generate report', 'error');
        } finally {
            elements.generateBtn.disabled = false;
            elements.generateBtn.textContent = originalBtnText;
        }
    }

    /* ================= SALES REPORT ================= */

    async function generateSalesReport() {
        const from = new Date(elements.dateFrom.value);
        const to = new Date(elements.dateTo.value);
        from.setHours(0, 0, 0, 0);
        to.setHours(23, 59, 59, 999);

        const payment = elements.paymentFilter.value;

        const snapshot = await db.collection(COLLECTIONS.BILLS)
            .where('createdAt', '>=', firebase.firestore.Timestamp.fromDate(from))
            .where('createdAt', '<=', firebase.firestore.Timestamp.fromDate(to))
            .get();

        const bills = [];
        const customerIds = new Set();

        snapshot.forEach(doc => {
            const bill = { id: doc.id, ...doc.data() };
            if (payment && bill.paymentMode !== payment) return;
            bills.push(bill);
            if (bill.customerId) customerIds.add(bill.customerId);
        });

        // Fetch customer names for display
        const customerMap = {};
        await Promise.all([...customerIds].map(async id => {
            const c = await db.collection(COLLECTIONS.CUSTOMERS).doc(id).get();
            if (c.exists) customerMap[id] = c.data().name;
        }));

        let totalProfit = 0;
        let totalSales = 0;
        let totalTax = 0;

        bills.forEach(b => {
            b.customerName = customerMap[b.customerId] || 'Walk-in';
            totalSales += (b.grandTotal || 0);
            totalTax += (b.totalTax || 0);

            let billProfit = 0;
            (b.items || []).forEach(item => {
                // Calculation: (Selling Price - Buying Price) * Quantity
                const sell = Number(item.unitPrice || item.price || 0);
                const buy = Number(item.buyingPrice || 0);
                const qty = Number(item.quantity || 0);
                billProfit += (sell - buy) * qty;
            });

            b.profit = billProfit;
            totalProfit += billProfit;
        });

        reportData.sales = bills;

        // Update Stats
        elements.totalSales.textContent = Utils.formatCurrency(totalSales);
        elements.totalBills.textContent = bills.length;
        elements.avgBill.textContent = Utils.formatCurrency(bills.length ? totalSales / bills.length : 0);
        elements.totalTax.textContent = Utils.formatCurrency(totalTax);
        elements.totalProfit.textContent = Utils.formatCurrency(totalProfit);
        elements.totalProfit.className = `stat-value ${totalProfit >= 0 ? 'text-success' : 'text-error'}`;

        // Render Table
        elements.salesTable.innerHTML = bills.length
            ? bills.map(b => `
                <tr>
                    <td>${Utils.formatDate(b.createdAt, true)}</td>
                    <td><code>${b.billNumber}</code></td>
                    <td>${Utils.sanitize(b.customerName)}</td>
                    <td>${b.items?.length || 0}</td>
                    <td>${Utils.formatCurrency(b.grandTotal)}</td>
                    <td class="${b.profit >= 0 ? 'text-success' : 'text-error'}" style="font-weight:600">
                        ${Utils.formatCurrency(b.profit)}
                    </td>
                    <td><span class="badge">${b.paymentMode}</span></td>
                </tr>
            `).join('')
            : '<tr><td colspan="7" class="text-center">No transactions found for this period.</td></tr>';
    }

    /* ================= INVENTORY REPORT ================= */

    async function generateInventoryReport() {
        const snapshot = await db.collection(COLLECTIONS.PRODUCTS).get();
        const products = [];
        const threshold = settings.lowStockThreshold || 10;

        let totalSellingValue = 0;
        let totalCostValue = 0;
        let low = 0, out = 0;

        snapshot.forEach(doc => {
            const p = doc.data();
            if (p.active === false) return;

            const stock = Number(p.stock || 0);
            const buyPrice = Number(p.buyingPrice || 0);
            const sellPrice = Number(p.price || 0);

            const costValue = stock * buyPrice;
            const sellingValue = stock * sellPrice;
            const potentialProfit = sellingValue - costValue;

            products.push({
                id: doc.id,
                ...p,
                costValue,
                sellingValue,
                potentialProfit
            });

            totalSellingValue += sellingValue;
            totalCostValue += costValue;
            if (stock === 0) out++;
            else if (stock <= threshold) low++;
        });

        reportData.inventory = products;

        // Update Stats
        elements.invTotalProducts.textContent = products.length;
        elements.invLowStock.textContent = low;
        elements.invOutStock.textContent = out;
        elements.invStockValue.textContent = Utils.formatCurrency(totalSellingValue);

        // Render Table
        elements.inventoryTable.innerHTML = products.length
            ? products.map(p => `
                <tr>
                    <td>${Utils.sanitize(p.name)}</td>
                    <td>${Utils.sanitize(p.category || 'General')}</td>
                    <td class="${p.stock <= threshold ? 'text-warning' : ''}">${p.stock}</td>
                    <td>${Utils.formatCurrency(p.buyingPrice)}</td>
                    <td>${Utils.formatCurrency(p.price)}</td>
                    <td>${Utils.formatCurrency(p.costValue)}</td>
                    <td class="text-success">${Utils.formatCurrency(p.potentialProfit)}</td>
                    <td>
                        <span class="badge ${p.stock === 0 ? 'badge-error' : p.stock <= threshold ? 'badge-warning' : 'badge-success'}">
                            ${p.stock === 0 ? 'Out' : p.stock <= threshold ? 'Low' : 'OK'}
                        </span>
                    </td>
                </tr>
            `).join('')
            : '<tr><td colspan="8" class="text-center">No products found.</td></tr>';
    }

    /* ================= CUSTOMER REPORT ================= */

    async function generateCustomerReport() {
        const snapshot = await db.collection(COLLECTIONS.CUSTOMERS).get();
        const customers = [];
        let totalRev = 0, totalDues = 0, activeCount = 0;

        snapshot.forEach(doc => {
            const c = { id: doc.id, ...doc.data() };
            customers.push(c);
            totalRev += (c.totalSpent || 0);
            totalDues += (c.totalDues || 0);
            if ((c.totalSpent || 0) > 0) activeCount++;
        });

        reportData.customers = customers;

        elements.custTotal.textContent = customers.length;
        elements.custActive.textContent = activeCount;
        elements.custRevenue.textContent = Utils.formatCurrency(totalRev);
        elements.custDues.textContent = Utils.formatCurrency(totalDues);

        elements.customersTable.innerHTML = customers.length
            ? customers.sort((a,b) => (b.totalSpent || 0) - (a.totalSpent || 0)).map(c => `
                <tr>
                    <td>${Utils.sanitize(c.name)}</td>
                    <td>${c.phone || '-'}</td>
                    <td>${Utils.formatCurrency(c.totalSpent || 0)}</td>
                    <td>${c.loyaltyPoints || 0}</td>
                    <td class="${(c.totalDues || 0) > 0 ? 'text-error' : ''}">${Utils.formatCurrency(c.totalDues || 0)}</td>
                </tr>
            `).join('')
            : '<tr><td colspan="5" class="text-center">No customers found.</td></tr>';
    }

    /* ================= CSV EXPORT ================= */

    function exportCSV() {
        if (!reportData[currentTab] || reportData[currentTab].length === 0) {
            return Utils.showToast('No data available to export', 'warning');
        }

        let csv = '';
        let filename = `${currentTab}_report_${new Date().toISOString().split('T')[0]}.csv`;

        if (currentTab === 'sales') {
            csv = 'Date,Bill Number,Customer,Grand Total,Profit,Payment Mode\n';
            reportData.sales.forEach(b => {
                csv += `"${Utils.formatDate(b.createdAt)}","${b.billNumber}","${b.customerName}",${b.grandTotal},${b.profit},"${b.paymentMode}"\n`;
            });
        } else if (currentTab === 'inventory') {
            csv = 'Product,Category,Stock,Buying Price,Selling Price,Potential Profit\n';
            reportData.inventory.forEach(p => {
                csv += `"${p.name}","${p.category}",${p.stock},${p.buyingPrice},${p.price},${p.potentialProfit}\n`;
            });
        }

        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement("a");
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    document.addEventListener('DOMContentLoaded', init);
    window.Reports = { init, generateReport };
})();