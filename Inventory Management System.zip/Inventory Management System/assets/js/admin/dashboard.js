/**
 * Admin Dashboard
 * Inventory Management System
 * 
 * Dashboard widget data loading and display.
 */

(function () {
    'use strict';

    const { COLLECTIONS, DEFAULT_SETTINGS, DUE_STATUS, BILL_STATUS } = window.APP_CONSTANTS || {};

    let db = null;
    let settings = DEFAULT_SETTINGS;

    /**
     * Initialize dashboard
     */
    async function init() {
        // Check auth and get user
        const user = await window.Guards.requireAdmin();
        if (!user) return;

        // Update user info in sidebar
        if (window.App && window.App.updateUserInfo) {
            window.App.updateUserInfo(user);
        }

        db = firebase.firestore();

        // Set current date
        document.getElementById('current-date').textContent = Utils.formatDate(new Date());

        // Load settings
        await loadSettings();

        // Load dashboard data
        try {
            await Promise.all([
                loadTodaySales(),
                loadProductStats(),
                loadPendingDues(),
                loadRecentBills(),
                loadLowStockItems()
            ]);
        } catch (error) {
            console.error('Loading Dashboard Data:', error);
        } finally {
            // Hide loading overlay
            const loadingOverlay = document.getElementById('loading');
            if (loadingOverlay) {
                loadingOverlay.style.display = 'none';
            }
        }
    }

    /**
     * Load store settings
     */
    async function loadSettings() {
        try {
            const settingsDoc = await db.collection(COLLECTIONS.SETTINGS).doc('config').get();
            if (settingsDoc.exists) {
                settings = { ...DEFAULT_SETTINGS, ...settingsDoc.data() };
            }
        } catch (error) {
            console.error('Error loading settings:', error);
        }
    }

    /**
     * Load today's sales total
     */
/**
 * Load today's sales total (realtime + timestamp safe)
 */
/**
 * Load today's sales AND profit (realtime)
 */
async function loadTodaySales() {
    try {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const startTs = firebase.firestore.Timestamp.fromDate(today);
        
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        const endTs = firebase.firestore.Timestamp.fromDate(tomorrow);

        if (window.__todaySalesUnsub) {
            window.__todaySalesUnsub();
        }

        window.__todaySalesUnsub = db.collection(COLLECTIONS.BILLS)
            .where('createdAt', '>=', startTs)
            .where('createdAt', '<', endTs)
            .where('status', '==', BILL_STATUS.COMPLETED)
            .onSnapshot(snapshot => {
                let totalSales = 0;
                let totalProfit = 0;

                snapshot.forEach(doc => {
                    const bill = doc.data();
                    totalSales += Number(bill.grandTotal || 0);

                    // Calculate profit for this bill
                    let billProfit = 0;
                    (bill.items || []).forEach(item => {
                        const sell = Number(item.unitPrice || item.price || 0);
                        const buy = Number(item.buyingPrice || 0);
                        const qty = Number(item.quantity || 0);
                        billProfit += (sell - buy) * qty;
                    });
                    totalProfit += billProfit;
                });

                // Update Sales UI
                document.getElementById('today-sales').textContent = Utils.formatCurrency(totalSales);
                
                // Update Profit UI
                const profitEl = document.getElementById('today-profit');
                if (profitEl) {
                    profitEl.textContent = Utils.formatCurrency(totalProfit);
                    // Optional: Change color to red if profit is negative
                    profitEl.style.color = totalProfit >= 0 ? '#10B981' : '#EF4444';
                }
            });

    } catch (error) {
        console.error('Loading Today Sales & Profit:', error);
        document.getElementById('today-sales').textContent = Utils.formatCurrency(0);
        document.getElementById('today-profit').textContent = Utils.formatCurrency(0);
    }
}



    /**
     * Load product statistics
     */
    async function loadProductStats() {
        try {
            const productsSnapshot = await db.collection(COLLECTIONS.PRODUCTS)
                .where('active', '==', true)
                .get();

            const totalProducts = productsSnapshot.size;
            let lowStockCount = 0;

            productsSnapshot.forEach(doc => {
                const product = doc.data();
                if (product.stock <= (settings.lowStockThreshold || 10)) {
                    lowStockCount++;
                }
            });

            document.getElementById('total-products').textContent = Utils.formatNumber(totalProducts);
            document.getElementById('low-stock-count').textContent = Utils.formatNumber(lowStockCount);
        } catch (error) {
            console.error('Loading Product Stats:', error);
            document.getElementById('total-products').textContent = '0';
            document.getElementById('low-stock-count').textContent = '0';
        }
    }

    /**
     * Load pending dues count
     */
    async function loadPendingDues() {
        try {
            const duesSnapshot = await db.collection(COLLECTIONS.DUES)
                .where('status', 'in', [DUE_STATUS.PENDING, DUE_STATUS.PARTIALLY_PAID])
                .get();

            let totalDues = 0;
            duesSnapshot.forEach(doc => {
                const due = doc.data();
                totalDues += due.remainingAmount || 0;
            });

            document.getElementById('pending-dues').textContent = Utils.formatCurrency(totalDues);
        } catch (error) {
            console.error('Loading Pending Dues:', error);
            document.getElementById('pending-dues').textContent = Utils.formatCurrency(0);
        }
    }

    /**
     * Load recent bills
     */
    async function loadRecentBills() {
        const tbody = document.getElementById('recent-bills');

        try {
            const billsSnapshot = await db.collection(COLLECTIONS.BILLS)
                .orderBy('createdAt', 'desc')
                .limit(5)
                .get();

            if (billsSnapshot.empty) {
                tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No bills yet</td></tr>';
                return;
            }

            // Get customer names
            const customerIds = new Set();
            billsSnapshot.forEach(doc => {
                const bill = doc.data();
                if (bill.customerId) customerIds.add(bill.customerId);
            });

            const customerMap = {};
            if (customerIds.size > 0) {
                const customerPromises = Array.from(customerIds).map(async id => {
                    const customerDoc = await db.collection(COLLECTIONS.CUSTOMERS).doc(id).get();
                    if (customerDoc.exists) {
                        customerMap[id] = customerDoc.data().name;
                    }
                });
                await Promise.all(customerPromises);
            }

            let html = '';
            billsSnapshot.forEach(doc => {
                const bill = doc.data();
                const customerName = bill.customerId ? (customerMap[bill.customerId] || 'Unknown') : 'Walk-in';

                html += `
                    <tr>
                        <td>${Utils.sanitize(bill.billNumber)}</td>
                        <td>${Utils.sanitize(customerName)}</td>
                        <td>${Utils.formatCurrency(bill.grandTotal)}</td>
                        <td><span class="badge badge-info">${bill.paymentMode}</span></td>
                        <td>${Utils.formatDate(bill.createdAt, true)}</td>
                    </tr>
                `;
            });

            tbody.innerHTML = html;
        } catch (error) {
            console.error('Loading Recent Bills:', error);
            tbody.innerHTML = '<tr><td colspan="5" class="text-center text-error">Loading Bills</td></tr>';
        }
    }

    /**
     * Load low stock items
     */
    async function loadLowStockItems() {
        const tbody = document.getElementById('low-stock-items');

        try {
            const productsSnapshot = await db.collection(COLLECTIONS.PRODUCTS)
                .where('active', '==', true)
                .get();

            const lowStockProducts = [];
            productsSnapshot.forEach(doc => {
                const product = doc.data();
                if (product.stock <= (settings.lowStockThreshold || 10)) {
                    lowStockProducts.push({ id: doc.id, ...product });
                }
            });

            // Sort by stock ascending
            lowStockProducts.sort((a, b) => a.stock - b.stock);

            if (lowStockProducts.length === 0) {
                tbody.innerHTML = '<tr><td colspan="3" class="text-center text-muted">No low stock items</td></tr>';
                return;
            }

            // Show top 5
            const topItems = lowStockProducts.slice(0, 5);

            let html = '';
            topItems.forEach(product => {
                const stockClass = product.stock === 0 ? 'text-error' : 'text-warning';
                html += `
                    <tr>
                        <td>${Utils.sanitize(product.name)}</td>
                        <td class="${stockClass}">${product.stock}</td>
                        <td>${Utils.sanitize(product.category || 'Uncategorized')}</td>
                    </tr>
                `;
            });

            tbody.innerHTML = html;
        } catch (error) {
            console.error('Loading Low Stock Items:', error);
            tbody.innerHTML = '<tr><td colspan="3" class="text-center text-error">Loading Items</td></tr>';
        }
    }

    // Initialize when DOM is ready
    document.addEventListener('DOMContentLoaded', init);

    // Export for global access
    window.Dashboard = {
        init,
        refresh: init
    };
})();
