/**
 * User Management
 * Inventory Management System
 * 
 * Handles user listing, role changes, and account status.
 */

(function () {
    'use strict';

    const { COLLECTIONS, ROLES, ERROR_MESSAGES, SUCCESS_MESSAGES } = window.APP_CONSTANTS || {};

    let db = null;
    let currentUser = null;
    let allUsers = [];
    let unsubscribe = null;

    // DOM Elements
    const elements = {};

    /**
     * Initialize users page
     */
    async function init() {
        currentUser = await window.Guards.requireAdmin();
        if (!currentUser) return;

        if (window.App && window.App.updateUserInfo) {
            window.App.updateUserInfo(currentUser);
        }

        db = firebase.firestore();

        cacheElements();
        setupEventListeners();
        loadUsers();
    }

    /**
     * Cache DOM elements
     */
    function cacheElements() {
        elements.usersTable = document.getElementById('users-table');
        elements.userCount = document.getElementById('user-count');
        elements.searchInput = document.getElementById('search-input');
        elements.roleFilter = document.getElementById('role-filter');
        elements.statusFilter = document.getElementById('status-filter');
        elements.userModal = document.getElementById('user-modal');
        elements.userForm = document.getElementById('user-form');
        elements.modalClose = document.getElementById('modal-close');
        elements.cancelBtn = document.getElementById('cancel-btn');
        elements.saveBtn = document.getElementById('save-btn');
        elements.userId = document.getElementById('user-id');
        elements.userName = document.getElementById('user-name');
        elements.userEmail = document.getElementById('user-email');
        elements.userRole = document.getElementById('user-role');
        elements.userActive = document.getElementById('user-active');
    }

    /**
     * Setup event listeners
     */
    function setupEventListeners() {
        // Modal
        elements.modalClose.addEventListener('click', closeModal);
        elements.cancelBtn.addEventListener('click', closeModal);
        elements.userModal.addEventListener('click', (e) => {
            if (e.target === elements.userModal) closeModal();
        });

        // Form submit
        elements.userForm.addEventListener('submit', saveUser);

        // Filters
        elements.searchInput.addEventListener('input', Utils.debounce(filterUsers, 300));
        elements.roleFilter.addEventListener('change', filterUsers);
        elements.statusFilter.addEventListener('change', filterUsers);
    }

    /**
     * Load users with real-time updates
     */
    function loadUsers() {
        if (unsubscribe) unsubscribe();

        // Query without orderBy, sort client-side
        unsubscribe = db.collection(COLLECTIONS.USERS)
            .onSnapshot((snapshot) => {
                allUsers = [];
                snapshot.forEach(doc => {
                    allUsers.push({ id: doc.id, ...doc.data() });
                });

                // Sort client-side by name
                allUsers.sort((a, b) => {
                    const nameA = (a.name || '').toLowerCase();
                    const nameB = (b.name || '').toLowerCase();
                    return nameA.localeCompare(nameB);
                });

                filterUsers();
            }, (error) => {
                console.error('Error loading users:', error);
                elements.usersTable.innerHTML = '<tr><td colspan="6" class="text-center text-error">Error loading users</td></tr>';
            });
    }

    /**
     * Filter and display users
     */
    function filterUsers() {
        const searchTerm = elements.searchInput.value.toLowerCase().trim();
        const roleFilter = elements.roleFilter.value;
        const statusFilter = elements.statusFilter.value;

        let filtered = allUsers.filter(user => {
            const matchesSearch = !searchTerm ||
                user.name.toLowerCase().includes(searchTerm) ||
                user.email.toLowerCase().includes(searchTerm);

            const matchesRole = !roleFilter || user.role === roleFilter;

            let matchesStatus = true;
            if (statusFilter === 'active') matchesStatus = user.active !== false;
            else if (statusFilter === 'inactive') matchesStatus = user.active === false;

            return matchesSearch && matchesRole && matchesStatus;
        });

        renderUsers(filtered);
    }

    /**
     * Render users table
     */
    function renderUsers(users) {
        if (users.length === 0) {
            elements.usersTable.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No users found</td></tr>';
            elements.userCount.textContent = 'No users to display';
            return;
        }

        const html = users.map(user => {
            const isActive = user.active !== false;
            const statusBadge = isActive
                ? '<span class="badge badge-success">Active</span>'
                : '<span class="badge badge-error">Inactive</span>';

            let roleBadge = '';
            switch (user.role) {
                case ROLES.ADMIN:
                    roleBadge = '<span class="badge badge-info">Admin</span>';
                    break;
                case ROLES.STAFF:
                    roleBadge = '<span class="badge badge-warning">Staff</span>';
                    break;
                default:
                    roleBadge = '<span class="badge">Customer</span>';
            }

            const isSelf = user.id === currentUser.id;

            return `
                <tr>
                    <td>${Utils.sanitize(user.name)}${isSelf ? ' (You)' : ''}</td>
                    <td>${Utils.sanitize(user.email)}</td>
                    <td>${roleBadge}</td>
                    <td>${statusBadge}</td>
                    <td>${Utils.formatDate(user.createdAt)}</td>
                    <td>
                        ${!isSelf ? `<button class="action-btn action-btn-edit" onclick="Users.editUser('${user.id}')">Edit</button>` : '-'}
                    </td>
                </tr>
            `;
        }).join('');

        elements.usersTable.innerHTML = html;
        elements.userCount.textContent = `Showing ${users.length} of ${allUsers.length} users`;
    }

    /**
     * Edit user
     */
    function editUser(userId) {
        const user = allUsers.find(u => u.id === userId);
        if (!user) return;

        elements.userId.value = user.id;
        elements.userName.value = user.name;
        elements.userEmail.value = user.email;
        elements.userRole.value = user.role || ROLES.CUSTOMER;
        elements.userActive.checked = user.active !== false;

        elements.userModal.classList.add('active');
    }

    /**
     * Close modal
     */
    function closeModal() {
        elements.userModal.classList.remove('active');
    }

    /**
     * Save user changes
     */
    async function saveUser(e) {
        e.preventDefault();

        const userId = elements.userId.value;
        const role = elements.userRole.value;
        const active = elements.userActive.checked;

        elements.saveBtn.disabled = true;
        elements.saveBtn.innerHTML = '<span class="spinner"></span> Saving...';

        try {
            await db.collection(COLLECTIONS.USERS).doc(userId).update({
                role: role,
                active: active,
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            Utils.showToast(SUCCESS_MESSAGES.USER_UPDATED, 'success');
            closeModal();
        } catch (error) {
            console.error('Error updating user:', error);
            Utils.showToast(ERROR_MESSAGES.GENERIC_ERROR, 'error');
        }

        elements.saveBtn.disabled = false;
        elements.saveBtn.textContent = 'Save Changes';
    }

    // Cleanup
    window.addEventListener('beforeunload', () => {
        if (unsubscribe) unsubscribe();
    });

    // Initialize when DOM is ready
    document.addEventListener('DOMContentLoaded', init);

    // Export for global access
    window.Users = {
        init,
        editUser
    };
})();
