/**
 * Settings Module
 * Inventory Management System
 * 
 * Handles system settings and configurations.
 */

(function () {
    'use strict';

    const { COLLECTIONS, DEFAULT_SETTINGS, SUCCESS_MESSAGES, ERROR_MESSAGES } = window.APP_CONSTANTS || {};

    let db = null;
    let currentUser = null;

    // DOM Elements
    const elements = {};

    /**
     * Initialize settings page
     */
    async function init() {
        currentUser = await window.Guards.requireAdmin();
        if (!currentUser) return;

        if (window.App && window.App.updateUserInfo) {
            window.App.updateUserInfo(currentUser);
        }

        db = firebase.firestore();

        cacheElements();
        setupEventListeners();
        await loadSettings();
    }

    /**
     * Cache DOM elements
     */
    function cacheElements() {
        elements.settingsForm = document.getElementById('settings-form');
        elements.storeName = document.getElementById('store-name');
        elements.storeAddress = document.getElementById('store-address');
        elements.storePhone = document.getElementById('store-phone');
        elements.lowStockThreshold = document.getElementById('low-stock-threshold');
        elements.loyaltyEnabled = document.getElementById('loyalty-enabled');
        elements.loyaltyPointsPerRupee = document.getElementById('loyalty-points-per-rupee');
        elements.loyaltyRedemptionValue = document.getElementById('loyalty-redemption-value');
        elements.defaultTax = document.getElementById('default-tax');
        elements.saveBtn = document.getElementById('save-settings-btn');
    }

    /**
     * Setup event listeners
     */
    function setupEventListeners() {
        elements.settingsForm.addEventListener('submit', saveSettings);
    }

    /**
     * Load current settings
     */
    async function loadSettings() {
        try {
            const doc = await db.collection(COLLECTIONS.SETTINGS).doc('config').get();

            let settings = DEFAULT_SETTINGS;
            if (doc.exists) {
                settings = { ...DEFAULT_SETTINGS, ...doc.data() };
            }

            // Populate form
            elements.storeName.value = settings.storeName || '';
            elements.storeAddress.value = settings.storeAddress || '';
            elements.storePhone.value = settings.storePhone || '';
            elements.lowStockThreshold.value = settings.lowStockThreshold || 10;
            elements.loyaltyEnabled.checked = settings.loyaltyEnabled !== false;
            elements.loyaltyPointsPerRupee.value = settings.loyaltyPointsPerRupee || 10;
            elements.loyaltyRedemptionValue.value = settings.loyaltyRedemptionValue || 0.5;
            elements.defaultTax.value = settings.defaultTax || 5;
        } catch (error) {
            console.error('Loading Settings:', error);
            Utils.showToast('Loading Settings', 'error');
        }
    }

    /**
     * Save settings
     */
    async function saveSettings(e) {
        e.preventDefault();

        elements.saveBtn.disabled = true;
        elements.saveBtn.innerHTML = '<span class="spinner"></span> Saving...';

        try {
            const settingsData = {
                storeName: elements.storeName.value.trim(),
                storeAddress: elements.storeAddress.value.trim(),
                storePhone: elements.storePhone.value.trim(),
                lowStockThreshold: parseInt(elements.lowStockThreshold.value) || 10,
                loyaltyEnabled: elements.loyaltyEnabled.checked,
                loyaltyPointsPerRupee: parseInt(elements.loyaltyPointsPerRupee.value) || 10,
                loyaltyRedemptionValue: parseFloat(elements.loyaltyRedemptionValue.value) || 0.5,
                defaultTax: parseFloat(elements.defaultTax.value) || 5,
                updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
                updatedBy: currentUser.id
            };

            await db.collection(COLLECTIONS.SETTINGS).doc('config').set(settingsData, { merge: true });

            Utils.showToast(SUCCESS_MESSAGES.SETTINGS_UPDATED, 'success');
        } catch (error) {
            console.error('Error saving settings:', error);
            Utils.showToast(ERROR_MESSAGES.GENERIC_ERROR, 'error');
        }

        elements.saveBtn.disabled = false;
        elements.saveBtn.textContent = 'Save Settings';
    }

    // Initialize when DOM is ready
    document.addEventListener('DOMContentLoaded', init);

    // Export for global access
    window.Settings = {
        init
    };
})();
