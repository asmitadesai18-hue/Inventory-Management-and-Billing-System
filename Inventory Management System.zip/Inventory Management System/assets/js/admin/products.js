/**
 * Product Management
 * Inventory Management System
 * 
 * Handles product CRUD operations.
 */

(function () {
    'use strict';

    const { COLLECTIONS, DEFAULT_CATEGORIES, ERROR_MESSAGES, SUCCESS_MESSAGES, INVENTORY_REASONS } = window.APP_CONSTANTS || {};

    let db = null;
    let currentUser = null;
    let allProducts = [];
    let allSuppliers = [];
    let unsubscribe = null;

    // DOM Elements
    const elements = {};

    /**
     * Initialize products page
     */
    async function init() {
        // Check auth and get user
        currentUser = await window.Guards.requireAdmin();
        if (!currentUser) return;

        // Update user info in sidebar
        if (window.App && window.App.updateUserInfo) {
            window.App.updateUserInfo(currentUser);
        }

        db = firebase.firestore();

        // Cache DOM elements
        cacheElements();

        // Setup event listeners
        setupEventListeners();

        // Load categories
        populateCategories();

        // Load suppliers
        await loadSuppliers();

        // Load products with real-time listener
        loadProducts();
    }

    /**
     * Cache DOM elements
     */
    function cacheElements() {
        elements.productsTable = document.getElementById('products-table');
        elements.productCount = document.getElementById('product-count');
        elements.searchInput = document.getElementById('search-input');
        elements.categoryFilter = document.getElementById('category-filter');
        elements.statusFilter = document.getElementById('status-filter');
        elements.addProductBtn = document.getElementById('add-product-btn');
        elements.productModal = document.getElementById('product-modal');
        elements.productForm = document.getElementById('product-form');
        elements.modalTitle = document.getElementById('modal-title');
        elements.modalClose = document.getElementById('modal-close');
        elements.cancelBtn = document.getElementById('cancel-btn');
        elements.saveBtn = document.getElementById('save-btn');
        elements.productId = document.getElementById('product-id');
        elements.productName = document.getElementById('product-name');
        elements.productBarcode = document.getElementById('product-barcode');
        elements.productBuyingPrice = document.getElementById('product-buying-price');

        elements.productCategory = document.getElementById('product-category');
        elements.productSupplier = document.getElementById('product-supplier');
        elements.productPrice = document.getElementById('product-price');
        elements.productTax = document.getElementById('product-tax');
        elements.productStock = document.getElementById('product-stock');
    }

    /**
     * Setup event listeners
     */
    function setupEventListeners() {
        // Add product button
        elements.addProductBtn.addEventListener('click', () => openModal());

        // Modal close buttons
        elements.modalClose.addEventListener('click', closeModal);
        elements.cancelBtn.addEventListener('click', closeModal);
        elements.productModal.addEventListener('click', (e) => {
            if (e.target === elements.productModal) closeModal();
        });

        // Form submit
        elements.productForm.addEventListener('submit', handleFormSubmit);

        // Search and filters with debounce
        elements.searchInput.addEventListener('input', Utils.debounce(filterProducts, 300));
        elements.categoryFilter.addEventListener('change', filterProducts);
        elements.statusFilter.addEventListener('change', filterProducts);
    }

    /**
     * Populate category dropdowns
     */
    function populateCategories() {
        const options = DEFAULT_CATEGORIES.map(cat => `<option value="${cat}">${cat}</option>`).join('');

        elements.categoryFilter.innerHTML = '<option value="">All Categories</option>' + options;
        elements.productCategory.innerHTML = '<option value="">Select Category</option>' + options;
    }

    /**
     * Load suppliers for dropdown
     */
    async function loadSuppliers() {
        try {
            // Query without orderBy to avoid composite index
            const snapshot = await db.collection(COLLECTIONS.SUPPLIERS)
                .where('active', '==', true)
                .get();

            allSuppliers = [];
            snapshot.forEach(doc => {
                allSuppliers.push({ id: doc.id, ...doc.data() });
            });

            // Sort client-side
            allSuppliers.sort((a, b) => (a.name || '').localeCompare(b.name || ''));

            populateSuppliers();
        } catch (error) {
            console.error('Error loading suppliers:', error);
        }
    }

    /**
     * Populate suppliers dropdown
     */
    function populateSuppliers() {
        if (!elements.productSupplier) return;
        const options = allSuppliers.map(s => `<option value="${s.id}">${Utils.sanitize(s.name)}</option>`).join('');
        elements.productSupplier.innerHTML = '<option value="">No Supplier (Optional)</option>' + options;
    }

    /**
     * Load products with real-time updates
     */
    function loadProducts() {
        // Unsubscribe from previous listener if exists
        if (unsubscribe) unsubscribe();

        // Set up real-time listener without orderBy
        unsubscribe = db.collection(COLLECTIONS.PRODUCTS)
            .onSnapshot((snapshot) => {
                allProducts = [];
                snapshot.forEach(doc => {
                    allProducts.push({ id: doc.id, ...doc.data() });
                });

                // Sort client-side by name
                allProducts.sort((a, b) => {
                    const nameA = (a.name || '').toLowerCase();
                    const nameB = (b.name || '').toLowerCase();
                    return nameA.localeCompare(nameB);
                });

                filterProducts();
            }, (error) => {
                console.error('Error loading products:', error);
                elements.productsTable.innerHTML = '<tr><td colspan="7" class="text-center text-error">Error loading products</td></tr>';
            });
    }

    /**
     * Filter and display products
     */
    function filterProducts() {
        const searchTerm = elements.searchInput.value.toLowerCase().trim();
        const categoryFilter = elements.categoryFilter.value;
        const statusFilter = elements.statusFilter.value;

        let filtered = allProducts.filter(product => {
            // Search filter
            const matchesSearch = !searchTerm ||
                product.name.toLowerCase().includes(searchTerm) ||
                (product.barcode && product.barcode.toLowerCase().includes(searchTerm)) ||
                (product.sku && product.sku.toLowerCase().includes(searchTerm));

            // Category filter
            const matchesCategory = !categoryFilter || product.category === categoryFilter;

            // Status filter
            let matchesStatus = true;
            if (statusFilter === 'active') matchesStatus = product.active !== false;
            else if (statusFilter === 'inactive') matchesStatus = product.active === false;

            return matchesSearch && matchesCategory && matchesStatus;
        });

        renderProducts(filtered);
    }

    /**
     * Render products table
     */
    function renderProducts(products) {
        if (products.length === 0) {
            elements.productsTable.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No products found</td></tr>';
            elements.productCount.textContent = 'No products to display';
            return;
        }

        const html = products.map(product => {
            const isActive = product.active !== false;
            const statusBadge = isActive
                ? '<span class="badge badge-success">Active</span>'
                : '<span class="badge badge-error">Inactive</span>';

            const stockClass = product.stock <= 10 ? (product.stock === 0 ? 'text-error' : 'text-warning') : '';

            return `
                <tr data-id="${product.id}">
                    <td>${Utils.sanitize(product.name)}</td>
                    <td><code>${Utils.sanitize(product.barcode)}</code></td>
                    <td>
                        <svg class="barcode-svg" id="barcode-${product.id}" data-barcode="${Utils.sanitize(product.barcode)}"></svg>
                    </td>
                    <td>${Utils.sanitize(product.category || '-')}</td>
                    <td>${Utils.formatCurrency(product.price)}</td>
                    <td class="${stockClass}">${product.stock}</td>
                    <td>${statusBadge}</td>
                    <td>
                        <div class="action-buttons">
                            <button class="action-btn action-btn-edit" onclick="Products.editProduct('${product.id}')">Edit</button>
                            ${isActive
                    ? `<button class="action-btn action-btn-delete" onclick="Products.disableProduct('${product.id}')">Disable</button>`
                    : `<button class="action-btn action-btn-view" onclick="Products.enableProduct('${product.id}')">Enable</button>`
                }
                        </div>
                    </td>
                </tr>
            `;
        }).join('');

        elements.productsTable.innerHTML = html;
        elements.productCount.textContent = `Showing ${products.length} of ${allProducts.length} products`;

        // Generate barcode images after rendering
        generateBarcodeImages();
    }

    /**
     * Generate barcode images using JsBarcode
     */
    function generateBarcodeImages() {
        if (typeof JsBarcode === 'undefined') {
            console.warn('JsBarcode library not loaded');
            return;
        }

        document.querySelectorAll('.barcode-svg').forEach(svg => {
            const barcodeValue = svg.getAttribute('data-barcode');
            if (barcodeValue) {
                try {
                    JsBarcode(svg, barcodeValue, {
                        format: 'CODE128',
                        width: 1,
                        height: 30,
                        displayValue: false,
                        margin: 2
                    });
                } catch (error) {
                    console.error('Error generating barcode for:', barcodeValue, error);
                    svg.innerHTML = '<text x="0" y="15" font-size="10" fill="#999">Invalid</text>';
                }
            }
        });
    }

    /**
     * Open modal for add/edit
     */
    function openModal(product = null) {
        elements.productForm.reset();
        clearErrors();

        if (product) {
            elements.modalTitle.textContent = 'Edit Product';
            elements.productId.value = product.id;
            elements.productName.value = product.name;
            elements.productBarcode.value = product.barcode;
            elements.productBuyingPrice.value = product.buyingPrice ?? 0;

            elements.productCategory.value = product.category || '';
            elements.productPrice.value = product.price;
            elements.productTax.value = product.tax || 0;
            elements.productStock.value = product.stock;
            elements.productStock.disabled = true; // Stock adjusted via inventory page

            // Set supplier
            if (elements.productSupplier) {
                elements.productSupplier.value = product.supplierId || '';
            }
        } else {
            elements.modalTitle.textContent = 'Add Product';
            elements.productId.value = '';
            elements.productStock.disabled = false;
            if (elements.productSupplier) {
                elements.productSupplier.value = '';
            }
        }

        elements.productModal.classList.add('active');
        elements.productName.focus();
    }

    /**
     * Close modal
     */
    function closeModal() {
        elements.productModal.classList.remove('active');
        elements.productForm.reset();
        clearErrors();
    }

    /**
     * Clear form errors
     */
    function clearErrors() {
        document.querySelectorAll('.form-error').forEach(el => el.textContent = '');
        document.querySelectorAll('.form-input.error, .form-select.error').forEach(el => el.classList.remove('error'));
    }

    /**
     * Handle form submit
     */
    async function handleFormSubmit(e) {
        e.preventDefault();

        if (!validateForm()) return;

        elements.saveBtn.disabled = true;
        elements.saveBtn.innerHTML = '<span class="spinner"></span> Saving...';

        const productId = elements.productId.value;
      const productData = {
    name: elements.productName.value.trim(),
    barcode: elements.productBarcode.value.trim(),
    category: elements.productCategory.value,
    buyingPrice: parseFloat(elements.productBuyingPrice.value),
    price: parseFloat(elements.productPrice.value), // selling price
    tax: parseFloat(elements.productTax.value) || 0,
    supplierId: elements.productSupplier ? elements.productSupplier.value || null : null,
    active: true,
    updatedAt: firebase.firestore.FieldValue.serverTimestamp()
};


        try {
            if (productId) {
                // Update existing product
                await db.collection(COLLECTIONS.PRODUCTS).doc(productId).update(productData);
                Utils.showToast(SUCCESS_MESSAGES.PRODUCT_UPDATED, 'success');
            } else {
                // Check barcode uniqueness
                const barcodeExists = await checkBarcodeExists(productData.barcode);
                if (barcodeExists) {
                    document.getElementById('barcode-error').textContent = ERROR_MESSAGES.PRODUCT_BARCODE_EXISTS;
                    elements.productBarcode.classList.add('error');
                    elements.saveBtn.disabled = false;
                    elements.saveBtn.textContent = 'Save Product';
                    return;
                }

                // Add stock for new product
                productData.stock = parseInt(elements.productStock.value);
                productData.createdAt = firebase.firestore.FieldValue.serverTimestamp();

                // Create product
                const docRef = db.collection(COLLECTIONS.PRODUCTS).doc(productData.barcode);
                await docRef.set(productData);

                // Create initial inventory log
                await db.collection(COLLECTIONS.INVENTORY_LOGS).add({
                 productId: docRef.id,
                 change: productData.stock,
                 previousStock: 0,
                 newStock: productData.stock,
                 reason: INVENTORY_REASONS.INITIAL,
                 notes: 'Initial stock on product creation',
                 performedBy: currentUser.id,
                  createdAt: firebase.firestore.FieldValue.serverTimestamp()
                });


                Utils.showToast(SUCCESS_MESSAGES.PRODUCT_ADDED, 'success');
            }

            closeModal();
        } catch (error) {
            console.error('Error saving product:', error);
            Utils.showToast(ERROR_MESSAGES.GENERIC_ERROR, 'error');
        }

        elements.saveBtn.disabled = false;
        elements.saveBtn.textContent = 'Save Product';
    }

    /**
     * Validate form
     */
    function validateForm() {
        let isValid = true;
        clearErrors();

        // Name
        if (!elements.productName.value.trim()) {
            document.getElementById('name-error').textContent = 'Product name is required';
            elements.productName.classList.add('error');
            isValid = false;
        }

        // Barcode
        if (!elements.productBarcode.value.trim()) {
            document.getElementById('barcode-error').textContent = 'Barcode is required';
            elements.productBarcode.classList.add('error');
            isValid = false;
        }

        // Category
        if (!elements.productCategory.value) {
            document.getElementById('category-error').textContent = 'Category is required';
            elements.productCategory.classList.add('error');
            isValid = false;
        }

        // Price
        const price = parseFloat(elements.productPrice.value);
        if (isNaN(price) || price < 0) {
            document.getElementById('price-error').textContent = 'Valid price is required';
            elements.productPrice.classList.add('error');
            isValid = false;
        }

        // Stock (only for new products)
        if (!elements.productId.value) {
            const stock = parseInt(elements.productStock.value);
            if (isNaN(stock) || stock < 0) {
                document.getElementById('stock-error').textContent = 'Valid stock quantity is required';
                elements.productStock.classList.add('error');
                isValid = false;
            }
        }

        // Buying Price
const buyingPrice = parseFloat(elements.productBuyingPrice.value);
if (isNaN(buyingPrice) || buyingPrice < 0) {
    document.getElementById('buying-price-error').textContent = 'Valid buying price is required';
    elements.productBuyingPrice.classList.add('error');
    isValid = false;
}


        return isValid;
    }

    /**
     * Check if barcode already exists
     */
    async function checkBarcodeExists(barcode, excludeId = null) {
        const snapshot = await db.collection(COLLECTIONS.PRODUCTS)
            .where('barcode', '==', barcode)
            .get();

        if (snapshot.empty) return false;

        // If editing, exclude current product
        if (excludeId) {
            return !snapshot.docs.every(doc => doc.id === excludeId);
        }

        return true;
    }

    /**
     * Edit product
     */
    function editProduct(productId) {
        const product = allProducts.find(p => p.id === productId);
        if (product) {
            openModal(product);
        }
    }

    /**
     * Disable product (soft delete)
     */
    async function disableProduct(productId) {
        const confirmed = await Utils.showConfirm('Are you sure you want to disable this product?', 'Disable', 'Cancel');
        if (!confirmed) return;

        try {
            await db.collection(COLLECTIONS.PRODUCTS).doc(productId).update({
                active: false,
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            });
            Utils.showToast(SUCCESS_MESSAGES.PRODUCT_DELETED, 'success');
        } catch (error) {
            console.error('Error disabling product:', error);
            Utils.showToast(ERROR_MESSAGES.GENERIC_ERROR, 'error');
        }
    }

    /**
     * Enable product
     */
    async function enableProduct(productId) {
        try {
            await db.collection(COLLECTIONS.PRODUCTS).doc(productId).update({
                active: true,
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            });
            Utils.showToast('Product enabled successfully', 'success');
        } catch (error) {
            console.error('Error enabling product:', error);
            Utils.showToast(ERROR_MESSAGES.GENERIC_ERROR, 'error');
        }
    }

    // Cleanup on page unload
    window.addEventListener('beforeunload', () => {
        if (unsubscribe) unsubscribe();
    });

    // Initialize when DOM is ready
    document.addEventListener('DOMContentLoaded', init);

    // Export for global access
    window.Products = {
        init,
        editProduct,
        disableProduct,
        enableProduct
    };
})();
