/**
 * Inventory Management
 * Inventory Management System
 * 
 * Handles inventory tracking, stock adjustments, and movement history.
 */

(function () {
    'use strict';

    const { COLLECTIONS, DEFAULT_CATEGORIES, DEFAULT_SETTINGS, INVENTORY_REASONS, ERROR_MESSAGES } = window.APP_CONSTANTS || {};

    let db = null;
    let currentUser = null;
    let allProducts = [];
    let settings = DEFAULT_SETTINGS;
    let unsubscribe = null;

    // DOM Elements
    const elements = {};

    /**
     * Initialize inventory page
     */
    async function init() {
        // Check auth and get user
        currentUser = await window.Guards.requireAdmin();
        if (!currentUser) return;

        // Update user info in sidebar
        if (window.App && window.App.updateUserInfo) {
            window.App.updateUserInfo(currentUser);
        }

        db = firebase.firestore();

        // Cache DOM elements
        cacheElements();

        // Setup event listeners
        setupEventListeners();

        // Load settings
        await loadSettings();

        // Populate categories
        populateCategories();

        // Load inventory data
        loadInventory();

        // Load movement history
        loadMovementHistory();
    }

    /**
     * Cache DOM elements
     */
    function cacheElements() {
        elements.inventoryTable = document.getElementById('inventory-table');
        elements.movementHistory = document.getElementById('movement-history');
        elements.totalProducts = document.getElementById('total-products');
        elements.lowStockCount = document.getElementById('low-stock-count');
        elements.outOfStockCount = document.getElementById('out-of-stock-count');
        elements.stockValue = document.getElementById('stock-value');
        elements.searchInput = document.getElementById('search-input');
        elements.stockFilter = document.getElementById('stock-filter');
        elements.categoryFilter = document.getElementById('category-filter');
        elements.adjustStockBtn = document.getElementById('adjust-stock-btn');
        elements.adjustmentModal = document.getElementById('adjustment-modal');
        elements.adjustmentForm = document.getElementById('adjustment-form');
        elements.productSelect = document.getElementById('product-select');
        elements.currentStock = document.getElementById('current-stock');
        elements.adjustmentType = document.getElementById('adjustment-type');
        elements.adjustmentQuantity = document.getElementById('adjustment-quantity');
        elements.adjustmentReason = document.getElementById('adjustment-reason');
        elements.adjustmentNotes = document.getElementById('adjustment-notes');
        elements.modalClose = document.getElementById('modal-close');
        elements.cancelBtn = document.getElementById('cancel-btn');
        elements.saveBtn = document.getElementById('save-btn');
    }

    /**
     * Setup event listeners
     */
    function setupEventListeners() {
        // Adjust stock button
        elements.adjustStockBtn.addEventListener('click', () => openModal());

        // Modal close buttons
        elements.modalClose.addEventListener('click', closeModal);
        elements.cancelBtn.addEventListener('click', closeModal);
        elements.adjustmentModal.addEventListener('click', (e) => {
            if (e.target === elements.adjustmentModal) closeModal();
        });

        // Product select change
        elements.productSelect.addEventListener('change', () => {
            const productId = elements.productSelect.value;
            const product = allProducts.find(p => p.id === productId);
            elements.currentStock.value = product ? product.stock : '';
        });

        // Form submit
        elements.adjustmentForm.addEventListener('submit', handleAdjustment);

        // Filters
        elements.searchInput.addEventListener('input', Utils.debounce(filterInventory, 300));
        elements.stockFilter.addEventListener('change', filterInventory);
        elements.categoryFilter.addEventListener('change', filterInventory);
    }

    /**
     * Load store settings
     */
    async function loadSettings() {
        try {
            const settingsDoc = await db.collection(COLLECTIONS.SETTINGS).doc('config').get();
            if (settingsDoc.exists) {
                settings = { ...DEFAULT_SETTINGS, ...settingsDoc.data() };
            }
        } catch (error) {
            console.error('Loading Settings:', error);
        }
    }

    /**
     * Populate category dropdown
     */
    function populateCategories() {
        const options = DEFAULT_CATEGORIES.map(cat => `<option value="${cat}">${cat}</option>`).join('');
        elements.categoryFilter.innerHTML = '<option value="">All Categories</option>' + options;
    }

    /**
     * Load inventory with real-time updates
     */
    function loadInventory() {
        if (unsubscribe) unsubscribe();

        // Query without orderBy to avoid composite index requirement
        unsubscribe = db.collection(COLLECTIONS.PRODUCTS)
            .where('active', '==', true)
            .onSnapshot((snapshot) => {
                allProducts = [];
                snapshot.forEach(doc => {
                    allProducts.push({ id: doc.id, ...doc.data() });
                });

                // Sort client-side by name
                allProducts.sort((a, b) => {
                    const nameA = (a.name || '').toLowerCase();
                    const nameB = (b.name || '').toLowerCase();
                    return nameA.localeCompare(nameB);
                });

                updateStats();
                populateProductSelect();
                filterInventory();
            }, (error) => {
                console.error('Loading Inventory:', error);
                elements.inventoryTable.innerHTML = '<tr><td colspan="6" class="text-center text-error">Loading Inventory</td></tr>';
            });
    }

    /**
     * Update inventory statistics
     */
    function updateStats() {
        const threshold = settings.lowStockThreshold || 10;

        let lowStock = 0;
        let outOfStock = 0;
        let totalValue = 0;

        allProducts.forEach(product => {
            if (product.stock === 0) {
                outOfStock++;
            } else if (product.stock <= threshold) {
                lowStock++;
            }
            totalValue += (product.price || 0) * (product.stock || 0);
        });

        elements.totalProducts.textContent = Utils.formatNumber(allProducts.length);
        elements.lowStockCount.textContent = Utils.formatNumber(lowStock);
        elements.outOfStockCount.textContent = Utils.formatNumber(outOfStock);
        elements.stockValue.textContent = Utils.formatCurrency(totalValue);
    }

    /**
     * Populate product select dropdown
     */
    function populateProductSelect() {
        const options = allProducts.map(p =>
            `<option value="${p.id}">${Utils.sanitize(p.name)} (${Utils.sanitize(p.barcode)})</option>`
        ).join('');
        elements.productSelect.innerHTML = '<option value="">Select a product</option>' + options;
    }

    /**
     * Filter and display inventory
     */
    function filterInventory() {
        const searchTerm = elements.searchInput.value.toLowerCase().trim();
        const stockFilter = elements.stockFilter.value;
        const categoryFilter = elements.categoryFilter.value;
        const threshold = settings.lowStockThreshold || 10;

        let filtered = allProducts.filter(product => {
            // Search filter
            const matchesSearch = !searchTerm ||
                product.name.toLowerCase().includes(searchTerm) ||
                (product.barcode && product.barcode.toLowerCase().includes(searchTerm));

            // Stock filter
            let matchesStock = true;
            if (stockFilter === 'low') {
                matchesStock = product.stock > 0 && product.stock <= threshold;
            } else if (stockFilter === 'out') {
                matchesStock = product.stock === 0;
            }

            // Category filter
            const matchesCategory = !categoryFilter || product.category === categoryFilter;

            return matchesSearch && matchesStock && matchesCategory;
        });

        renderInventory(filtered);
    }

    /**
     * Render inventory table
     */
    function renderInventory(products) {
        if (products.length === 0) {
            elements.inventoryTable.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No items found</td></tr>';
            return;
        }

        const threshold = settings.lowStockThreshold || 10;

        const html = products.map(product => {
            let status, statusClass;
            if (product.stock === 0) {
                status = 'Out of Stock';
                statusClass = 'badge-error';
            } else if (product.stock <= threshold) {
                status = 'Low Stock';
                statusClass = 'badge-warning';
            } else {
                status = 'In Stock';
                statusClass = 'badge-success';
            }

            const stockClass = product.stock === 0 ? 'text-error' : (product.stock <= threshold ? 'text-warning' : '');

            return `
                <tr>
                    <td>${Utils.sanitize(product.name)}</td>
                    <td><code>${Utils.sanitize(product.barcode)}</code></td>
                    <td>${Utils.sanitize(product.category || '-')}</td>
                    <td class="${stockClass}"><strong>${product.stock}</strong></td>
                    <td><span class="badge ${statusClass}">${status}</span></td>
                    <td>
                        <button class="action-btn action-btn-edit" onclick="Inventory.adjustProduct('${product.id}')">Adjust</button>
                    </td>
                </tr>
            `;
        }).join('');

        elements.inventoryTable.innerHTML = html;
    }

    /**
     * Load movement history
     */
    async function loadMovementHistory() {
        try {
            const logsSnapshot = await db.collection(COLLECTIONS.INVENTORY_LOGS)
                .orderBy('createdAt', 'desc')
                .limit(10)
                .get();

            if (logsSnapshot.empty) {
                elements.movementHistory.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No movements yet</td></tr>';
                return;
            }

            // Get product names and user names
            const productIds = new Set();
            const userIds = new Set();
            logsSnapshot.forEach(doc => {
                const log = doc.data();
                if (log.productId) productIds.add(log.productId);
                if (log.performedBy) userIds.add(log.performedBy);
            });

            const productMap = {};
            const userMap = {};

            // Fetch product names
            await Promise.all(Array.from(productIds).map(async id => {
                const productDoc = await db.collection(COLLECTIONS.PRODUCTS).doc(id).get();
                if (productDoc.exists) {
                    productMap[id] = productDoc.data().name;
                }
            }));

            // Fetch user names
            await Promise.all(Array.from(userIds).map(async id => {
                const userDoc = await db.collection(COLLECTIONS.USERS).doc(id).get();
                if (userDoc.exists) {
                    userMap[id] = userDoc.data().name;
                }
            }));

            let html = '';
            logsSnapshot.forEach(doc => {
                const log = doc.data();
                const productName = productMap[log.productId] || 'Unknown';
                const userName = userMap[log.performedBy] || 'Unknown';
                const changeClass = log.change > 0 ? 'text-success' : 'text-error';
                const changeText = log.change > 0 ? `+${log.change}` : log.change;

                html += `
                    <tr>
                        <td>${Utils.sanitize(productName)}</td>
                        <td class="${changeClass}"><strong>${changeText}</strong></td>
                        <td>${Utils.sanitize(log.reason)}${log.notes ? ` - ${Utils.sanitize(log.notes)}` : ''}</td>
                        <td>${Utils.sanitize(userName)}</td>
                        <td>${Utils.formatDate(log.createdAt, true)}</td>
                    </tr>
                `;
            });

            elements.movementHistory.innerHTML = html;
        } catch (error) {
            console.error('Loading Movement History:', error);
            elements.movementHistory.innerHTML = '<tr><td colspan="5" class="text-center text-error">Loading History</td></tr>';
        }
    }

    /**
     * Open adjustment modal
     */
    function openModal(productId = null) {
        elements.adjustmentForm.reset();
        elements.currentStock.value = '';
        clearErrors();

        if (productId) {
            elements.productSelect.value = productId;
            const product = allProducts.find(p => p.id === productId);
            if (product) {
                elements.currentStock.value = product.stock;
            }
        }

        elements.adjustmentModal.classList.add('active');
    }

    /**
     * Close modal
     */
    function closeModal() {
        elements.adjustmentModal.classList.remove('active');
        elements.adjustmentForm.reset();
        clearErrors();
    }

    /**
     * Clear form errors
     */
    function clearErrors() {
        document.querySelectorAll('.form-error').forEach(el => el.textContent = '');
        document.querySelectorAll('.form-input.error, .form-select.error').forEach(el => el.classList.remove('error'));
    }

    /**
     * Handle stock adjustment
     */
    async function handleAdjustment(e) {
        e.preventDefault();

        const productId = elements.productSelect.value;
        const adjustmentType = elements.adjustmentType.value;
        const quantity = parseInt(elements.adjustmentQuantity.value);
        const reason = elements.adjustmentReason.value;
        const notes = elements.adjustmentNotes.value.trim();

        // Validation
        if (!productId) {
            document.getElementById('product-error').textContent = 'Please select a product';
            return;
        }

        if (!quantity || quantity < 1) {
            document.getElementById('quantity-error').textContent = 'Please enter a valid quantity';
            return;
        }

        const product = allProducts.find(p => p.id === productId);
        if (!product) {
            Utils.showToast('Product not found', 'error');
            return;
        }

        const change = adjustmentType === 'add' ? quantity : -quantity;
        const newStock = product.stock + change;

        if (newStock < 0) {
            document.getElementById('quantity-error').textContent = 'Cannot reduce stock below zero';
            return;
        }

        elements.saveBtn.disabled = true;
        elements.saveBtn.innerHTML = '<span class="spinner"></span> Saving...';

        try {
            // Use batch to ensure atomicity
            const batch = db.batch();

            // Update product stock
            const productRef = db.collection(COLLECTIONS.PRODUCTS).doc(productId);
            batch.update(productRef, {
                stock: newStock,
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            // Create inventory log
            const logRef = db.collection(COLLECTIONS.INVENTORY_LOGS).doc();
            batch.set(logRef, {
                productId: productId,
                change: change,
                previousStock: product.stock,
                newStock: newStock,
                reason: INVENTORY_REASONS.MANUAL_ADJUSTMENT,
                notes: `${reason}${notes ? ': ' + notes : ''}`,
                performedBy: currentUser.id,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            await batch.commit();

            Utils.showToast('Stock adjusted successfully', 'success');
            closeModal();
            loadMovementHistory();
        } catch (error) {
            console.error('Error adjusting stock:', error);
            Utils.showToast(ERROR_MESSAGES.GENERIC_ERROR, 'error');
        }

        elements.saveBtn.disabled = false;
        elements.saveBtn.textContent = 'Save Adjustment';
    }

    /**
     * Adjust specific product
     */
    function adjustProduct(productId) {
        openModal(productId);
    }

    // Cleanup on page unload
    window.addEventListener('beforeunload', () => {
        if (unsubscribe) unsubscribe();
    });

    // Initialize when DOM is ready
    document.addEventListener('DOMContentLoaded', init);

    // Export for global access
    window.Inventory = {
        init,
        adjustProduct
    };
})();
