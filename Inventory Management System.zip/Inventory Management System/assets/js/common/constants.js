/**
 * Constants
 * Inventory Management System
 * 
 * Central location for all application constants, enums, and configuration values.
 */

// User Roles
const ROLES = {
    ADMIN: 'ADMIN',
    STAFF: 'STAFF'
};

// Role Labels (for display)
const ROLE_LABELS = {
    [ROLES.ADMIN]: 'Administrator',
    [ROLES.STAFF]: 'Staff'
};

// Payment Modes
const PAYMENT_MODES = {
    CASH: 'CASH',
    CARD: 'CARD',
    UPI: 'UPI'
};

// Payment Mode Labels
const PAYMENT_MODE_LABELS = {
    [PAYMENT_MODES.CASH]: 'Cash',
    [PAYMENT_MODES.CARD]: 'Card',
    [PAYMENT_MODES.UPI]: 'UPI'
};

// Bill Status
const BILL_STATUS = {
    COMPLETED: 'COMPLETED',
    CANCELLED: 'CANCELLED',
    HOLD: 'HOLD'
};

// Due Status
const DUE_STATUS = {
    PENDING: 'PENDING',
    PARTIALLY_PAID: 'PARTIALLY_PAID',
    PAID: 'PAID'
};

// Inventory Log Reasons
const INVENTORY_REASONS = {
    BILLING: 'BILLING',
    MANUAL_ADJUSTMENT: 'MANUAL_ADJUSTMENT',
    INITIAL: 'INITIAL',
    REFUND: 'REFUND'
};

// Loyalty Log Types
const LOYALTY_TYPES = {
    CREDIT: 'CREDIT',
    DEBIT: 'DEBIT'
};

// Firestore Collection Names
const COLLECTIONS = {
    USERS: 'users',
    PRODUCTS: 'products',
    INVENTORY_LOGS: 'inventoryLogs',
    CUSTOMERS: 'customers',
    BILLS: 'bills',
    DUES: 'dues',
    LOYALTY_LOGS: 'loyaltyLogs',
    SETTINGS: 'settings',
    SUPPLIERS: 'suppliers'
};

// Default Settings
const DEFAULT_SETTINGS = {
    storeName: 'My Grocery Store',
    storeAddress: '',
    storePhone: '',
    taxEnabled: true,
    defaultTax: 5,
    loyaltyEnabled: true,
    loyaltyPointsPerRupee: 10, // 1 point per 10 rupees
    loyaltyRedemptionValue: 0.5, // 1 point = 0.5 rupees
    lowStockThreshold: 10
};

// Product Categories (Default)
const DEFAULT_CATEGORIES = [
    'Grains',
    'Dairy',
    'Beverages',
    'Snacks',
    'Fruits',
    'Vegetables',
    'Personal Care',
    'Household',
    'Frozen',
    'Bakery',
    'Other'
];

// Route Paths (for navigation and guards)
const ROUTES = {
    // Public
    INDEX: '/index.html',
    LOGIN: '/login.html',
    REGISTER: '/register.html',

    // Admin
    ADMIN_DASHBOARD: '/admin/dashboard.html',
    ADMIN_PRODUCTS: '/admin/products.html',
    ADMIN_INVENTORY: '/admin/inventory.html',
    ADMIN_REPORTS: '/admin/reports.html',
    ADMIN_USERS: '/admin/users.html',
    ADMIN_SETTINGS: '/admin/settings.html',
    ADMIN_SUPPLIERS: '/admin/suppliers.html',

    // Staff
    STAFF_BILLING: '/staff/billing.html',
    STAFF_CUSTOMERS: '/staff/customers.html',
    STAFF_DUES: '/staff/dues.html',

};

// Role-based route access
const ROUTE_ACCESS = {
    [ROUTES.ADMIN_DASHBOARD]: [ROLES.ADMIN],
    [ROUTES.ADMIN_PRODUCTS]: [ROLES.ADMIN],
    [ROUTES.ADMIN_INVENTORY]: [ROLES.ADMIN],
    [ROUTES.ADMIN_REPORTS]: [ROLES.ADMIN],
    [ROUTES.ADMIN_USERS]: [ROLES.ADMIN],
    [ROUTES.ADMIN_SETTINGS]: [ROLES.ADMIN],
    [ROUTES.ADMIN_SUPPLIERS]: [ROLES.ADMIN],
    [ROUTES.STAFF_BILLING]: [ROLES.ADMIN, ROLES.STAFF],
    [ROUTES.STAFF_CUSTOMERS]: [ROLES.ADMIN, ROLES.STAFF],
    [ROUTES.STAFF_DUES]: [ROLES.ADMIN, ROLES.STAFF],
};

// Default redirect after login based on role
const DEFAULT_REDIRECTS = {
    [ROLES.ADMIN]: ROUTES.ADMIN_DASHBOARD,
    [ROLES.STAFF]: ROUTES.STAFF_BILLING
};

// Error Messages
const ERROR_MESSAGES = {
    NETWORK_ERROR: 'Network error. Please check your connection and try again.',
    AUTH_INVALID_CREDENTIALS: 'Invalid email or password.',
    AUTH_USER_NOT_FOUND: 'No account found with this email.',
    AUTH_WRONG_PASSWORD: 'Incorrect password.',
    AUTH_EMAIL_IN_USE: 'An account with this email already exists.',
    AUTH_WEAK_PASSWORD: 'Password must be at least 6 characters.',
    AUTH_UNAUTHORIZED: 'You do not have permission to access this page.',
    PRODUCT_BARCODE_EXISTS: 'A product with this barcode already exists.',
    PRODUCT_NOT_FOUND: 'Product not found.',
    CUSTOMER_PHONE_EXISTS: 'A customer with this phone number already exists.',
    SUPPLIER_PHONE_EXISTS: 'A supplier with this phone number already exists.',
    SUPPLIER_NOT_FOUND: 'Supplier not found.',
    INSUFFICIENT_STOCK: 'Insufficient stock available.',
    INSUFFICIENT_POINTS: 'Insufficient loyalty points.',
    GENERIC_ERROR: 'Something went wrong. Please try again.'
};

// Success Messages
const SUCCESS_MESSAGES = {
    LOGIN_SUCCESS: 'Logged in successfully.',
    LOGOUT_SUCCESS: 'Logged out successfully.',
    REGISTER_SUCCESS: 'Account created successfully.',
    PRODUCT_ADDED: 'Product added successfully.',
    PRODUCT_UPDATED: 'Product updated successfully.',
    PRODUCT_DELETED: 'Product disabled successfully.',
    CUSTOMER_ADDED: 'Customer added successfully.',
    CUSTOMER_UPDATED: 'Customer updated successfully.',
    BILL_COMPLETED: 'Bill completed successfully.',
    PAYMENT_RECORDED: 'Payment recorded successfully.',
    SETTINGS_UPDATED: 'Settings updated successfully.',
    SUPPLIER_ADDED: 'Supplier added successfully.',
    SUPPLIER_UPDATED: 'Supplier updated successfully.',
    SUPPLIER_DELETED: 'Supplier disabled successfully.'
};

// Make constants available globally
window.APP_CONSTANTS = {
    ROLES,
    ROLE_LABELS,
    PAYMENT_MODES,
    PAYMENT_MODE_LABELS,
    BILL_STATUS,
    DUE_STATUS,
    INVENTORY_REASONS,
    LOYALTY_TYPES,
    COLLECTIONS,
    DEFAULT_SETTINGS,
    DEFAULT_CATEGORIES,
    ROUTES,
    ROUTE_ACCESS,
    DEFAULT_REDIRECTS,
    ERROR_MESSAGES,
    SUCCESS_MESSAGES
};
