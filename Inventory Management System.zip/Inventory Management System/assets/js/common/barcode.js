/**
 * Barcode Scanner
 * Inventory Management System
 * 
 * Handles barcode input from keyboard/USB scanner and camera.
 */

(function () {
    'use strict';

    let videoStream = null;
    let isScanning = false;
    let onBarcodeCallback = null;

    /**
     * Initialize barcode input handler
     * @param {HTMLInputElement} input - Barcode input element
     * @param {Function} callback - Callback when barcode is scanned
     */
    function initBarcodeInput(input, callback) {
        if (!input) return;

        onBarcodeCallback = callback;

        // Handle Enter key (USB barcode scanners typically send Enter after barcode)
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                const barcode = input.value.trim();
                if (barcode) {
                    handleBarcode(barcode);
                    input.value = '';
                }
            }
        });

        // Auto-focus on input when typing starts
        document.addEventListener('keydown', (e) => {
            // If typing alphanumeric and input is not focused, focus it
            if (/^[a-zA-Z0-9]$/.test(e.key) &&
                document.activeElement !== input &&
                !document.activeElement.matches('input, textarea, select')) {
                input.focus();
            }
        });
    }

    /**
     * Handle scanned barcode
     * @param {string} barcode 
     */
    function handleBarcode(barcode) {
        const cleanBarcode = Utils.parseBarcode(barcode);
        if (cleanBarcode && onBarcodeCallback) {
            onBarcodeCallback(cleanBarcode);
        }
    }

    /**
     * Start camera scanning
     * @param {HTMLVideoElement} video - Video element for preview
     * @param {Function} callback - Callback when barcode is detected
     */
    async function startCameraScanning(video, callback) {
        if (isScanning) return;

        try {
            const constraints = {
                video: {
                    facingMode: 'environment', // Prefer back camera
                    width: { ideal: 640 },
                    height: { ideal: 480 }
                }
            };

            videoStream = await navigator.mediaDevices.getUserMedia(constraints);
            video.srcObject = videoStream;
            isScanning = true;

            // Note: Full ZXing integration would require the ZXing library
            // For now, we rely on manual barcode input
            // Camera preview is shown but actual barcode detection from camera
            // would need ZXing-js library integration

            console.log('Camera scanning started');

            // Placeholder for actual barcode detection
            // In production, integrate with @aspect-build/aspect-ratio-core or zxing-js

        } catch (error) {
            console.error('Error starting camera:', error);
            Utils.showToast('Could not access camera. Please use manual barcode input.', 'warning');
            throw error;
        }
    }

    /**
     * Stop camera scanning
     */
    function stopCameraScanning() {
        if (videoStream) {
            videoStream.getTracks().forEach(track => track.stop());
            videoStream = null;
        }
        isScanning = false;
        console.log('Camera scanning stopped');
    }

    /**
     * Toggle camera scanning
     * @param {HTMLVideoElement} video 
     * @param {HTMLElement} container 
     * @param {Function} callback 
     */
    async function toggleCamera(video, container, callback) {
        if (isScanning) {
            stopCameraScanning();
            container.classList.remove('active');
        } else {
            try {
                await startCameraScanning(video, callback);
                container.classList.add('active');
            } catch (error) {
                container.classList.remove('active');
            }
        }
        return isScanning;
    }

    /**
     * Check if camera is available
     * @returns {Promise<boolean>}
     */
    async function isCameraAvailable() {
        try {
            const devices = await navigator.mediaDevices.enumerateDevices();
            return devices.some(device => device.kind === 'videoinput');
        } catch (error) {
            return false;
        }
    }

    // Export globally
    window.BarcodeScanner = {
        initBarcodeInput,
        startCameraScanning,
        stopCameraScanning,
        toggleCamera,
        isCameraAvailable,
        handleBarcode
    };
})();
