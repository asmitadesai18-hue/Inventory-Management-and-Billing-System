/**
 * Utility Functions
 * Inventory Management System
 * 
 * Common helper functions used throughout the application.
 */

/**
 * Format currency (Indian Rupees)
 * @param {number} amount 
 * @returns {string}
 */
function formatCurrency(amount) {
    const formatted = new Intl.NumberFormat('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(amount);
    return '₹' + formatted;
}

/**
 * Format number with commas (Indian format)
 * @param {number} num 
 * @returns {string}
 */
function formatNumber(num) {
    return new Intl.NumberFormat('en-IN').format(num);
}

/**
 * Format date to readable string
 * @param {Date|firebase.firestore.Timestamp|string} date 
 * @param {boolean} includeTime 
 * @returns {string}
 */
function formatDate(date, includeTime = false) {
    let dateObj;

    if (date instanceof Date) {
        dateObj = date;
    } else if (date && date.toDate) {
        // Firebase Timestamp
        dateObj = date.toDate();
    } else if (typeof date === 'string') {
        dateObj = new Date(date);
    } else {
        return '-';
    }

    const options = {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    };

    if (includeTime) {
        options.hour = '2-digit';
        options.minute = '2-digit';
    }

    return dateObj.toLocaleDateString('en-IN', options);
}

/**
 * Format date for input fields (YYYY-MM-DD)
 * @param {Date} date 
 * @returns {string}
 */
function formatDateForInput(date) {
    const d = date instanceof Date ? date : new Date(date);
    return d.toISOString().split('T')[0];
}

/**
 * Get start and end of day for date filtering
 * @param {Date} date 
 * @returns {{start: Date, end: Date}}
 */
function getDayBounds(date) {
    const start = new Date(date);
    start.setHours(0, 0, 0, 0);

    const end = new Date(date);
    end.setHours(23, 59, 59, 999);

    return { start, end };
}

/**
 * Generate unique bill number
 * Format: BILL-YYYYMMDD-XXXX (where XXXX is random)
 * @returns {string}
 */
function generateBillNumber() {
    const now = new Date();
    const datePart = now.toISOString().slice(0, 10).replace(/-/g, '');
    const randomPart = Math.floor(1000 + Math.random() * 9000);
    return `BILL-${datePart}-${randomPart}`;
}

/**
 * Debounce function for search inputs
 * @param {Function} func 
 * @param {number} wait 
 * @returns {Function}
 */
function debounce(func, wait = 300) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Validate email format
 * @param {string} email 
 * @returns {boolean}
 */
function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

/**
 * Validate phone number (Indian format)
 * @param {string} phone 
 * @returns {boolean}
 */
function isValidPhone(phone) {
    const re = /^[6-9]\d{9}$/;
    return re.test(phone.replace(/\s/g, ''));
}

/**
 * Sanitize string for safe display
 * @param {string} str 
 * @returns {string}
 */
function sanitize(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

/**
 * Show loading overlay
 * @param {string} message 
 */
function showLoading(message = 'Loading...') {
    let overlay = document.getElementById('loading-overlay');

    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'loading-overlay';
        overlay.className = 'loading-overlay';
        overlay.innerHTML = `
            <div style="text-align: center;">
                <div class="spinner" style="width: 40px; height: 40px; margin: 0 auto 16px;"></div>
                <p id="loading-message" style="color: var(--color-text-secondary);">${sanitize(message)}</p>
            </div>
        `;
        document.body.appendChild(overlay);
    } else {
        document.getElementById('loading-message').textContent = message;
        overlay.style.display = 'flex';
    }
}

/**
 * Hide loading overlay
 */
function hideLoading() {
    const overlay = document.getElementById('loading-overlay');
    if (overlay) {
        overlay.style.display = 'none';
    }
}

/**
 * Show toast notification
 * @param {string} message 
 * @param {string} type - 'success', 'error', 'warning', 'info'
 * @param {number} duration - in milliseconds
 */
function showToast(message, type = 'info', duration = 3000) {
    // Remove existing toasts
    const existingToasts = document.querySelectorAll('.toast-notification');
    existingToasts.forEach(t => t.remove());

    const toast = document.createElement('div');
    toast.className = `toast-notification toast-${type}`;
    toast.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 12px 24px;
        border-radius: 4px;
        font-size: 14px;
        z-index: 10000;
        animation: slideIn 0.3s ease;
    `;

    // Set colors based on type
    const colors = {
        success: { bg: '#D1FAE5', text: '#065F46', border: '#10B981' },
        error: { bg: '#FEE2E2', text: '#991B1B', border: '#EF4444' },
        warning: { bg: '#FEF3C7', text: '#92400E', border: '#F59E0B' },
        info: { bg: '#E0F2FE', text: '#0369A1', border: '#0EA5E9' }
    };

    const color = colors[type] || colors.info;
    toast.style.backgroundColor = color.bg;
    toast.style.color = color.text;
    toast.style.border = `1px solid ${color.border}`;

    toast.textContent = message;
    document.body.appendChild(toast);

    // Add animation keyframes if not exists
    if (!document.getElementById('toast-styles')) {
        const style = document.createElement('style');
        style.id = 'toast-styles';
        style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    }

    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

/**
 * Show confirmation modal
 * @param {string} message 
 * @param {string} confirmText 
 * @param {string} cancelText 
 * @returns {Promise<boolean>}
 */
function showConfirm(message, confirmText = 'Confirm', cancelText = 'Cancel') {
    return new Promise((resolve) => {
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay active';
        overlay.innerHTML = `
            <div class="modal" style="max-width: 400px;">
                <div class="modal-header">
                    <h3 class="modal-title">Confirm Action</h3>
                </div>
                <div class="modal-body">
                    <p>${sanitize(message)}</p>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" id="confirm-cancel">${sanitize(cancelText)}</button>
                    <button class="btn btn-primary" id="confirm-ok">${sanitize(confirmText)}</button>
                </div>
            </div>
        `;

        document.body.appendChild(overlay);

        document.getElementById('confirm-ok').onclick = () => {
            overlay.remove();
            resolve(true);
        };

        document.getElementById('confirm-cancel').onclick = () => {
            overlay.remove();
            resolve(false);
        };

        overlay.onclick = (e) => {
            if (e.target === overlay) {
                overlay.remove();
                resolve(false);
            }
        };
    });
}

/**
 * Get initials from name
 * @param {string} name 
 * @returns {string}
 */
function getInitials(name) {
    if (!name) return '?';
    return name
        .split(' ')
        .map(word => word[0])
        .join('')
        .toUpperCase()
        .slice(0, 2);
}

/**
 * Calculate percentage
 * @param {number} value 
 * @param {number} total 
 * @returns {number}
 */
function calculatePercentage(value, total) {
    if (total === 0) return 0;
    return Math.round((value / total) * 100);
}

/**
 * Deep clone an object
 * @param {Object} obj 
 * @returns {Object}
 */
function deepClone(obj) {
    return JSON.parse(JSON.stringify(obj));
}

/**
 * Get current timestamp for Firestore
 * @returns {firebase.firestore.FieldValue}
 */
function getTimestamp() {
    return firebase.firestore.FieldValue.serverTimestamp();
}

/**
 * Convert Firestore document to object with ID
 * @param {firebase.firestore.DocumentSnapshot} doc 
 * @returns {Object}
 */
function docToObject(doc) {
    if (!doc.exists) return null;
    return { id: doc.id, ...doc.data() };
}

/**
 * Convert Firestore query snapshot to array
 * @param {firebase.firestore.QuerySnapshot} snapshot 
 * @returns {Array}
 */
function snapshotToArray(snapshot) {
    const results = [];
    snapshot.forEach(doc => {
        results.push({ id: doc.id, ...doc.data() });
    });
    return results;
}

/**
 * Export data to CSV
 * @param {Array} data - Array of objects
 * @param {string} filename 
 */
function exportToCSV(data, filename = 'export.csv') {
    if (!data || data.length === 0) {
        showToast('No data to export', 'warning');
        return;
    }

    const headers = Object.keys(data[0]);
    const csvContent = [
        headers.join(','),
        ...data.map(row =>
            headers.map(header => {
                let value = row[header];
                if (value === null || value === undefined) value = '';
                if (typeof value === 'string' && value.includes(',')) {
                    value = `"${value}"`;
                }
                return value;
            }).join(',')
        )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    link.click();
    URL.revokeObjectURL(link.href);
}

/**
 * Parse barcode input (handles both keyboard and scanner input)
 * @param {string} input 
 * @returns {string}
 */
function parseBarcode(input) {
    // Remove any non-alphanumeric characters except hyphens
    return input.replace(/[^a-zA-Z0-9-]/g, '').trim();
}

// Make utilities available globally
window.Utils = {
    formatCurrency,
    formatNumber,
    formatDate,
    formatDateForInput,
    getDayBounds,
    generateBillNumber,
    debounce,
    isValidEmail,
    isValidPhone,
    sanitize,
    showLoading,
    hideLoading,
    showToast,
    showConfirm,
    getInitials,
    calculatePercentage,
    deepClone,
    getTimestamp,
    docToObject,
    snapshotToArray,
    exportToCSV,
    parseBarcode
};
