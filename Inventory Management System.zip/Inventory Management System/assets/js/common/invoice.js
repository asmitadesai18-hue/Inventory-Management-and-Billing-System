/**
 * Invoice Generator
 * Inventory Management System
 * 
 * Generates and prints invoice receipts.
 */

(function () {
    'use strict';

        function generateInvoice(billData, storeSettings = {}) {
        const storeName = storeSettings.storeName || 'My Grocery Store';
        const storeAddress = storeSettings.storeAddress || '';
        const storePhone = storeSettings.storePhone || '';

        const itemsHtml = billData.items.map(item => {
         const itemSubtotal = item.unitPrice * item.quantity;
        const gstAmount = (itemSubtotal * item.tax / 100).toFixed(2);

        return `
        <tr>
            <td style="text-align:left;padding:4px 0;">${Utils.sanitize(item.name)}</td>
            <td style="text-align:center;padding:4px 0;">${item.quantity}</td>
            <td style="text-align:right;padding:4px 0;">${Utils.formatCurrency(item.unitPrice)}</td>
            <td style="text-align:right;padding:4px 0;">
                ${item.tax}% (${Utils.formatCurrency(gstAmount)})
            </td>
            <td style="text-align:right;padding:4px 0;">
                ${Utils.formatCurrency(itemSubtotal)}
            </td>
             </tr>
            `;
        }).join('');


        const invoiceHtml = `
        <div style="font-family:'Courier New', monospace;font-size:12px;max-width:300px;margin:0 auto;">
            
            <div style="text-align:center;margin-bottom:16px;">
                <h2 style="margin:0;font-size:16px;">${Utils.sanitize(storeName)}</h2>
                ${storeAddress ? `<p style="margin:4px 0;font-size:11px;">${Utils.sanitize(storeAddress)}</p>` : ''}
                ${storePhone ? `<p style="margin:4px 0;font-size:11px;">Tel: ${Utils.sanitize(storePhone)}</p>` : ''}
            </div>

            <hr style="border:none;border-top:1px dashed #000;margin:8px 0;">

            <div style="margin-bottom:12px;">
                <div style="display:flex;justify-content:space-between;">
                    <span>Bill No:</span>
                    <span>${Utils.sanitize(billData.billNumber)}</span>
                </div>
                <div style="display:flex;justify-content:space-between;">
                    <span>Date:</span>
                    <span>${
                        billData.invoiceDate
                            ? Utils.formatDate(billData.invoiceDate, true)
                            : billData.createdAt?.toDate
                                ? Utils.formatDate(billData.createdAt.toDate(), true)
                                : Utils.formatDate(billData.createdAt || new Date(), true)
                    }</span>
                </div>
                ${billData.customerName ? `
                <div style="display:flex;justify-content:space-between;">
                    <span>Customer:</span>
                    <span>${Utils.sanitize(billData.customerName)}</span>
                </div>` : ''}
            </div>

            <hr style="border:none;border-top:1px dashed #000;margin:8px 0;">

            <table style="width:100%;border-collapse:collapse;margin-bottom:12px;">
                <thead>
                    <tr style="border-bottom:1px solid #000;">
                        <th style="text-align:left;font-size:11px;">Item</th>
                        <th style="text-align:center;font-size:11px;">Qty</th>
                        <th style="text-align:right;font-size:11px;">Rate</th>
                        <th style="text-align:right;font-size:11px;">GST</th>
                        <th style="text-align:right;font-size:11px;">Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    ${itemsHtml}
                </tbody>
            </table>

            <hr style="border:none;border-top:1px dashed #000;margin:8px 0;">

            <div style="margin-bottom:12px;">
                <div style="display:flex;justify-content:space-between;">
                    <span>Amt:</span>
                    <span>${Utils.formatCurrency(billData.subtotal)}</span>
                </div>
                ${billData.totalTax > 0 ? `
                <div style="display:flex;justify-content:space-between;">
                    <span>Tax:</span>
                    <span>${Utils.formatCurrency(billData.totalTax)}</span>
                </div>` : ''}
                ${billData.discount > 0 ? `
                <div style="display:flex;justify-content:space-between;">
                    <span>Discount:</span>
                    <span>-${Utils.formatCurrency(billData.discount)}</span>
                </div>` : ''}
                ${billData.loyaltyPointsUsed > 0 ? `
                <div style="display:flex;justify-content:space-between;">
                    <span>Points Redeemed:</span>
                    <span>-${Utils.formatCurrency(billData.loyaltyPointsUsed * 0.5)}</span>
                </div>` : ''}

                <div style="display:flex;justify-content:space-between;font-weight:bold;font-size:14px;margin-top:8px;border-top:1px solid #000;padding-top:8px;">
                    <span>TOTAL:</span>
                    <span>${Utils.formatCurrency(billData.grandTotal)}</span>
                </div>
            </div>

            <div style="display:flex;justify-content:space-between;">
    <span>Payment Mode:</span>
    <span>${billData.paymentMode}</span>
</div>

${billData.cashAmount > 0 ? `
<div style="display:flex;justify-content:space-between;">
    <span>Cash Paid:</span>
    <span>${Utils.formatCurrency(billData.cashAmount)}</span>
</div>` : ''}

${billData.upiAmount > 0 ? `
<div style="display:flex;justify-content:space-between;">
    <span>UPI Paid:</span>
    <span>${Utils.formatCurrency(billData.upiAmount)}</span>
</div>` : ''}

<div style="display:flex;justify-content:space-between;font-weight:bold;">
    <span>Total Paid:</span>
    <span>${Utils.formatCurrency(billData.amountPaid)}</span>
</div>

${billData.dueAmount > 0 ? `
<div style="display:flex;justify-content:space-between;color:red;">
    <span>Due:</span>
    <span>${Utils.formatCurrency(billData.dueAmount)}</span>
</div>` : ''}

${billData.amountPaid > billData.grandTotal ? `
<div style="display:flex;justify-content:space-between;">
    <span>Change:</span>
    <span>${Utils.formatCurrency(billData.amountPaid - billData.grandTotal)}</span>
</div>` : ''}

            </div>

            ${billData.loyaltyPointsEarned > 0 ? `
            <div style="text-align:center;background:#f0f0f0;padding:8px;margin-bottom:12px;">
                <small>Points Earned: +${billData.loyaltyPointsEarned}</small>
            </div>` : ''}

            <hr style="border:none;border-top:1px dashed #000;margin:8px 0;">

            <div style="text-align:center;font-size:11px;">
                <p style="margin:4px 0;">Thank you for shopping!</p>
                <p style="margin:4px 0;">Please visit again</p>
            </div>

        </div>
        `;

        return invoiceHtml;
    }

    function printInvoice(invoiceHtml) {
        const printWindow = window.open('', '_blank', 'width=350,height=600');

        printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Invoice</title>
            <style>
                body{margin:0;padding:10px;font-family:'Courier New',monospace;}
                @media print{body{margin:0;padding:0;}}
            </style>
        </head>
        <body>
            ${invoiceHtml}
            <script>
                window.onload=function(){
                    window.print();
                    setTimeout(function(){window.close();},500);
                }
            </script>
        </body>
        </html>
        `);

        printWindow.document.close();
    }

    function displayInvoice(invoiceHtml, container) {
        if (container) {
            container.innerHTML = invoiceHtml;
        }
    }

    window.Invoice = {
        generate: generateInvoice,
        print: printInvoice,
        display: displayInvoice
    };
})();
