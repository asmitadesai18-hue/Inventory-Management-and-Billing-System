/**
 * Dynamic Sidebar Component
 * Inventory Management System
 * 
 * Generates sidebar navigation based on user role.
 */

(function () {
    'use strict';

    const { ROUTES, ROUTE_ACCESS, ROLES } = window.APP_CONSTANTS || {};

    // Define all sidebar navigation items with their details
    const SIDEBAR_ITEMS = [
        {
            id: 'dashboard',
            label: 'Dashboard',
            href: '/admin/dashboard.html',
            staffHref: '../admin/dashboard.html',
            adminHref: 'dashboard.html',
            icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="3" y="3" width="7" height="7" />
                <rect x="14" y="3" width="7" height="7" />
                <rect x="14" y="14" width="7" height="7" />
                <rect x="3" y="14" width="7" height="7" />
            </svg>`,
            access: [ROLES.ADMIN]
        },
        {
            id: 'products',
            label: 'Products',
            href: '/admin/products.html',
            staffHref: '../admin/products.html',
            adminHref: 'products.html',
            icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
                <polyline points="3.27 6.96 12 12.01 20.73 6.96" />
                <line x1="12" y1="22.08" x2="12" y2="12" />
            </svg>`,
            access: [ROLES.ADMIN]
        },
        {
            id: 'suppliers',
            label: 'Suppliers',
            href: '/admin/suppliers.html',
            staffHref: '../admin/suppliers.html',
            adminHref: 'suppliers.html',
            icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="1" y="3" width="15" height="13" />
                <polygon points="16 8 20 8 23 11 23 16 16 16 16 8" />
                <circle cx="5.5" cy="18.5" r="2.5" />
                <circle cx="18.5" cy="18.5" r="2.5" />
            </svg>`,
            access: [ROLES.ADMIN]
        },
        {
            id: 'inventory',
            label: 'Inventory',
            href: '/admin/inventory.html',
            staffHref: '../admin/inventory.html',
            adminHref: 'inventory.html',
            icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M5 8h14M5 8a2 2 0 1 0-4 0 2 2 0 0 0 4 0zM5 8v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8m0 0a2 2 0 1 0 4 0 2 2 0 0 0-4 0z" />
            </svg>`,
            access: [ROLES.ADMIN]
        },
        {
            id: 'users',
            label: 'Users',
            href: '/admin/users.html',
            staffHref: '../admin/users.html',
            adminHref: 'users.html',
            icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>`,
            access: [ROLES.ADMIN]
        },
        {
            id: 'billing',
            label: 'Billing',
            href: '/staff/billing.html',
            staffHref: 'billing.html',
            adminHref: '../staff/billing.html',
            icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="1" y="4" width="22" height="16" rx="2" ry="2" />
                <line x1="1" y1="10" x2="23" y2="10" />
            </svg>`,
            access: [ROLES.ADMIN, ROLES.STAFF]
        },
        {
            id: 'customers',
            label: 'Customers',
            href: '/staff/customers.html',
            staffHref: 'customers.html',
            adminHref: '../staff/customers.html',
            icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                <circle cx="12" cy="7" r="4" />
            </svg>`,
            access: [ROLES.ADMIN, ROLES.STAFF]
        },
        {
            id: 'dues',
            label: 'Dues',
            href: '/staff/dues.html',
            staffHref: 'dues.html',
            adminHref: '../staff/dues.html',
            icon: `<span style="font-size: 18px; font-weight: bold; width: 18px; display: inline-block; text-align: center;">₹</span>`,
            access: [ROLES.ADMIN, ROLES.STAFF]
        },
        {
            id: 'reports',
            label: 'Reports',
            href: '/admin/reports.html',
            staffHref: '../admin/reports.html',
            adminHref: 'reports.html',
            icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="20" x2="18" y2="10" />
                <line x1="12" y1="20" x2="12" y2="4" />
                <line x1="6" y1="20" x2="6" y2="14" />
            </svg>`,
            access: [ROLES.ADMIN]
        },
        {
            id: 'settings',
            label: 'Settings',
            href: '/admin/settings.html',
            staffHref: '../admin/settings.html',
            adminHref: 'settings.html',
            icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="3" />
                <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
            </svg>`,
            access: [ROLES.ADMIN]
        },
        // Customer Pages
        {
            id: 'profile',
            label: 'Profile',
            href: '/customer/profile.html',
            staffHref: '../customer/profile.html',
            adminHref: '../customer/profile.html',
            customerHref: 'profile.html',
            icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                <circle cx="12" cy="7" r="4" />
            </svg>`,
            access: [ROLES.CUSTOMER]
        },
        {
            id: 'history',
            label: 'Purchase History',
            href: '/customer/history.html',
            staffHref: '../customer/history.html',
            adminHref: '../customer/history.html',
            customerHref: 'history.html',
            icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="10" />
                <polyline points="12 6 12 12 16 14" />
            </svg>`,
            access: [ROLES.CUSTOMER]
        }
    ];

    /**
     * Check if user has access to a navigation item
     * @param {Object} item - Navigation item
     * @param {string} userRole - User's role
     * @returns {boolean}
     */
    function hasAccessToItem(item, userRole) {
        if (!item.access || item.access.length === 0) {
            return true; // No restrictions
        }
        return item.access.includes(userRole);
    }

    /**
     * Get appropriate href for the current page context
     * @param {Object} item - Navigation item
     * @returns {string}
     */
    function getHref(item) {
        const path = window.location.pathname;

        if (path.includes('/staff/')) {
            return item.staffHref;
        } else if (path.includes('/admin/')) {
            return item.adminHref;
        } else if (path.includes('/customer/')) {
            return item.customerHref || item.href;
        }

        return item.href;
    }

    /**
     * Check if navigation item is currently active
     * @param {Object} item - Navigation item
     * @returns {boolean}
     */
    function isActive(item) {
        const path = window.location.pathname;
        return path.includes(item.id + '.html');
    }

    /**
     * Generate sidebar HTML for user role
     * @param {string} userRole - User's role
     * @returns {string}
     */
    function generateSidebarHTML(userRole) {
        const accessibleItems = SIDEBAR_ITEMS.filter(item => hasAccessToItem(item, userRole));

        let html = '<ul class="sidebar-nav">';

        accessibleItems.forEach(item => {
            const href = getHref(item);
            const activeClass = isActive(item) ? ' active' : '';

            html += `
                <li>
                    <a href="${href}" class="sidebar-link${activeClass}">
                        ${item.icon}
                        ${item.label}
                    </a>
                </li>
            `;
        });

        html += '</ul>';

        return html;
    }

    /**
     * Update sidebar navigation based on user role
     * @param {string} userRole - User's role
     */
    function updateSidebar(userRole) {
        const sidebarNav = document.querySelector('.dashboard-sidebar nav');

        if (!sidebarNav) {
            console.warn('Sidebar navigation not found');
            return;
        }

        if (!userRole) {
            console.warn('User role not provided');
            return;
        }

        const sidebarHTML = generateSidebarHTML(userRole);
        sidebarNav.innerHTML = sidebarHTML;
    }

    /**
     * Initialize sidebar with user role
     * Called after user authentication is confirmed
     * @param {Object} userData - User data with role
     */
    function initSidebar(userData) {
        if (userData && userData.role) {
            updateSidebar(userData.role);
        }
    }

    // Export functions globally
    window.Sidebar = {
        init: initSidebar,
        update: updateSidebar,
        generateHTML: generateSidebarHTML,
        SIDEBAR_ITEMS
    };
})();
