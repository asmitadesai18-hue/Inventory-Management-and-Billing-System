/**
 * Dues Management
 * Inventory Management System
 *
 * Handles customer dues and payment recording.
 */

function generateId() {
    return (
        Date.now().toString(36) +
        Math.random().toString(36).substring(2, 10)
    );
}

(function () {
    'use strict';

    const COLLECTIONS = window.APP_CONSTANTS?.COLLECTIONS || {};
const DUE_STATUS = window.APP_CONSTANTS?.DUE_STATUS || {
    PENDING: 'PENDING',
    PARTIALLY_PAID: 'PARTIALLY_PAID',
    PAID: 'PAID'
};
const ERROR_MESSAGES = window.APP_CONSTANTS?.ERROR_MESSAGES || {};


    let db = null;
    let currentUser = null;
    let allDues = [];
    let customerMap = {};
    let unsubscribe = null;

    // DOM Elements
    const elements = {};

    /** =========================
     *  INIT
     * ========================= */
    async function init() {
        currentUser = await window.Guards.requireStaff();
        if (!currentUser) return;

        if (window.App?.updateUserInfo) {
            window.App.updateUserInfo(currentUser);
        }

        if (currentUser.role === 'ADMIN') {
            document.querySelectorAll('.nav-admin-only')
                .forEach(el => el.style.display = 'block');
        }

        db = firebase.firestore();

        cacheElements();
        setupEventListeners();
        loadDues();
    }

    function cacheElements() {
        elements.duesTable = document.getElementById('dues-table');
        elements.totalPending = document.getElementById('total-pending');
        elements.customersWithDues = document.getElementById('customers-with-dues');
        elements.overdueCount = document.getElementById('overdue-count');

        elements.searchInput = document.getElementById('search-input');
        elements.statusFilter = document.getElementById('status-filter');

        elements.paymentModal = document.getElementById('payment-modal');
        elements.paymentForm = document.getElementById('payment-form');
        elements.modalClose = document.getElementById('modal-close');
        elements.cancelBtn = document.getElementById('cancel-btn');
        elements.saveBtn = document.getElementById('save-btn');

        elements.dueId = document.getElementById('due-id');
        elements.paymentCustomer = document.getElementById('payment-customer');
        elements.remainingAmount = document.getElementById('remaining-amount');
        elements.paymentAmount = document.getElementById('payment-amount');
        elements.paymentMode = document.getElementById('payment-mode');
        elements.paymentNotes = document.getElementById('payment-notes');
    }

    function setupEventListeners() {
        elements.modalClose.addEventListener('click', closeModal);
        elements.cancelBtn.addEventListener('click', closeModal);

        elements.paymentModal.addEventListener('click', e => {
            if (e.target === elements.paymentModal) closeModal();
        });

        elements.paymentForm.addEventListener('submit', handlePayment);

        elements.searchInput.addEventListener(
            'input',
            Utils.debounce(filterDues, 300)
        );

        elements.statusFilter.addEventListener('change', filterDues);
    }

    /** =========================
     *  LOAD DUES
     * ========================= */
    function loadDues() {
        if (unsubscribe) unsubscribe();

        unsubscribe = db.collection(COLLECTIONS.DUES)
            .orderBy('createdAt', 'desc')
            .onSnapshot(async snapshot => {
                allDues = [];
                const customerIds = new Set();

                snapshot.forEach(doc => {
                    const d = { id: doc.id, ...doc.data() };
                    allDues.push(d);
                    if (d.customerId) customerIds.add(d.customerId);
                });

                await loadCustomerNames([...customerIds]);
                updateStats();
                filterDues();
            }, err => {
                console.error(err);
                elements.duesTable.innerHTML =
                    `<tr><td colspan="7" class="text-error text-center">
                        Failed to load dues
                     </td></tr>`;
            });
    }

    async function loadCustomerNames(ids) {
        customerMap = {};
        await Promise.all(ids.map(async id => {
            try {
                const doc = await db.collection(COLLECTIONS.CUSTOMERS).doc(id).get();
                customerMap[id] = doc.exists ? doc.data().name : 'Unknown';
            } catch {
                customerMap[id] = 'Error';
            }
        }));
    }

    /** =========================
     *  STATS
     * ========================= */
    function updateStats() {
        const pending = allDues.filter(d => d.status !== DUE_STATUS.PAID);
        const totalPending = pending.reduce((s, d) => s + (d.remainingAmount || 0), 0);

        const customers = new Set(pending.map(d => d.customerId)).size;

        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

        const overdue = pending.filter(d => {
            if (!d.createdAt) return false;
            const dt = d.createdAt.toDate
                ? d.createdAt.toDate()
                : new Date(d.createdAt);
            return dt < thirtyDaysAgo;
        }).length;

        elements.totalPending.textContent = Utils.formatCurrency(totalPending);
        elements.customersWithDues.textContent = customers;
        elements.overdueCount.textContent = overdue;
    }

    /** =========================
     *  FILTER + RENDER
     * ========================= */
    function filterDues() {
        const q = elements.searchInput.value.toLowerCase().trim();
        const status = elements.statusFilter.value;

        const filtered = allDues.filter(d => {
            const name = (customerMap[d.customerId] || '').toLowerCase();
            const bill = (d.billId || '').toLowerCase();

            const matchesSearch =
                !q || name.includes(q) || bill.includes(q);

            const matchesStatus =
                status === 'all' || d.status === status;

            return matchesSearch && matchesStatus;
        });

        renderDues(filtered);
    }

    function renderDues(dues) {
        if (!dues.length) {
            elements.duesTable.innerHTML =
                `<tr><td colspan="7" class="text-muted text-center">
                    No dues found
                 </td></tr>`;
            return;
        }

        elements.duesTable.innerHTML = dues.map(d => {
            const badge = d.status === DUE_STATUS.PAID
                ? 'success'
                : d.status === DUE_STATUS.PARTIALLY_PAID
                    ? 'warning'
                    : 'error';

            return `
                <tr>
                    <td>${Utils.sanitize(customerMap[d.customerId] || 'Unknown')}</td>
                    <td><code>${Utils.sanitize(d.billId || '-')}</code></td>
                    <td>${Utils.formatCurrency(d.originalAmount)}</td>
                    <td class="text-error">${Utils.formatCurrency(d.remainingAmount)}</td>
                    <td><span class="badge badge-${badge}">
                        ${d.status.replace('_', ' ')}
                    </span></td>
                    <td>${Utils.formatDate(d.createdAt)}</td>
                    <td>
                        ${d.status !== DUE_STATUS.PAID
                            ? `<button class="action-btn action-btn-edit"
                                 onclick="Dues.openPaymentModal('${d.id}')">
                                 Record Payment
                               </button>`
                            : '-'}
                    </td>
                </tr>
            `;
        }).join('');
    }

    /** =========================
     *  PAYMENT MODAL
     * ========================= */
    function openPaymentModal(id) {
        const due = allDues.find(d => d.id === id);
        if (!due) return;

        elements.paymentForm.reset();
        document.getElementById('amount-error').textContent = '';

        elements.dueId.value = due.id;
        elements.paymentCustomer.value = customerMap[due.customerId] || 'Unknown';
        elements.remainingAmount.value = Utils.formatCurrency(due.remainingAmount);

        elements.paymentAmount.max = due.remainingAmount;
        elements.paymentAmount.value = due.remainingAmount;

        elements.paymentModal.classList.add('active');
        elements.paymentAmount.focus();
    }

    function closeModal() {
        elements.paymentModal.classList.remove('active');
        elements.paymentForm.reset();
    }

   /* =========================
   Handle Due Payment
========================= */
/* =========================
   Handle Due Payment
========================= */
async function handlePayment(e) {
    e.preventDefault();

    const dueId = elements.dueId.value;

    // Money precision safety
    const amount = Math.round(Number(elements.paymentAmount.value) * 100) / 100;
    const mode = elements.paymentMode.value;
    const notes = elements.paymentNotes.value.trim();

    const due = allDues.find(d => d.id === dueId);
    if (!due) return;

    // Block payment if already paid
    if (due.status === DUE_STATUS.PAID) {
        Utils.showToast('This due is already fully paid', 'warning');
        return;
    }

    const remaining =
        Math.round(Number(due.remainingAmount) * 100) / 100;

    const errorEl = document.getElementById('amount-error');
    errorEl.textContent = '';

    // Validation
    if (!amount || amount <= 0) {
        errorEl.textContent = 'Enter a valid amount';
        return;
    }

    if (amount > remaining) {
        errorEl.textContent =
            'Maximum payable amount is ${Utils.formatCurrency(remaining)}';
        return;
    }

    // Disable submit
    elements.saveBtn.disabled = true;
    elements.saveBtn.innerHTML = '<span class="spinner"></span> Recording...';

    try {
        const newRemaining =
            Math.round((remaining - amount) * 100) / 100;

        const newStatus =
            newRemaining === 0
                ? DUE_STATUS.PAID
                : DUE_STATUS.PARTIALLY_PAID;

        // ✅ SAFE payment object (NO serverTimestamp inside array)
        const payment = {
            id: generateId(),
            amount,
            mode,
            notes: notes || null,
            recordedBy: currentUser.id,
            recordedAt: new Date() // ✅ FIXED
        };

        const batch = db.batch();

        // Update due
        const dueRef =
            db.collection(COLLECTIONS.DUES).doc(dueId);

        batch.update(dueRef, {
            remainingAmount: newRemaining,
            status: newStatus,
            payments: firebase.firestore.FieldValue.arrayUnion(payment),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });

        // Update customer total dues
        if (due.customerId) {
            const customerRef =
                db.collection(COLLECTIONS.CUSTOMERS).doc(due.customerId);

            const customerSnap = await customerRef.get();
            if (customerSnap.exists) {
                batch.update(customerRef, {
                    totalDues:
                        firebase.firestore.FieldValue.increment(-amount),
                    updatedAt:
                        firebase.firestore.FieldValue.serverTimestamp()
                });
            }
        }

        // Commit batch
        await batch.commit();

        Utils.showToast('Payment recorded successfully', 'success');
        closeModal();

    } catch (err) {
        console.error('Payment Error:', err);
        Utils.showToast(
            'Failed to record payment. Please try again.',
            'error'
        );
    } finally {
        elements.saveBtn.disabled = false;
        elements.saveBtn.textContent = 'Record Payment';
    }
}



    window.addEventListener('beforeunload', () => {
        if (unsubscribe) unsubscribe();
    });

    document.addEventListener('DOMContentLoaded', init);

    window.Dues = {
        init,
        openPaymentModal
    };

})();