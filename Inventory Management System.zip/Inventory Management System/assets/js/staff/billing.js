
/**
 * POS Billing
 * Inventory Management System
 * 
 * Core billing logic with cart management, payment processing, and invoice generation.
 */


let pendingBillData = null;
let pendingPaymentMode = null;
let paymentBreakup = {
    cash: 0,
    upi: 0
};





(function () {
    'use strict';

    const {
        COLLECTIONS,
        BILL_STATUS,
        PAYMENT_MODES,
        INVENTORY_REASONS,
        LOYALTY_TYPES,
        DUE_STATUS,
        DEFAULT_SETTINGS,
        ERROR_MESSAGES,
        SUCCESS_MESSAGES
    } = window.APP_CONSTANTS || {};

    let db = null;
    let currentUser = null;
    let settings = DEFAULT_SETTINGS;

    // Cart state
    let cart = [];
    let selectedCustomer = null;
    let loyaltyPointsToRedeem = 0;
    let heldBills = [];

    // DOM Elements
    const elements = {};

    /** =========================
     *  INIT
     * ========================= */
    async function init() {
        currentUser = await window.Guards.requireStaff();
        if (!currentUser) return;

        if (window.App?.updateUserInfo)
            window.App.updateUserInfo(currentUser);

        if (currentUser.role === 'ADMIN') {
            document.querySelectorAll('.nav-admin-only')
                .forEach(el => el.style.display = 'block');
        }

        db = firebase.firestore();

        cacheElements();
        setupEventListeners();
        await loadSettings();

        if (window.BarcodeScanner) {
            window.BarcodeScanner.initBarcodeInput(
                elements.barcodeInput,
                handleBarcodeScanned
            );
        }

        loadHeldBills();
        updateCartUI();
        updateTotals();
    }

    function cacheElements() {
        elements.barcodeInput = document.getElementById('barcode-input');
        elements.cameraToggle = document.getElementById('camera-toggle');
        elements.cameraPreview = document.getElementById('camera-preview');
        elements.scannerVideo = document.getElementById('scanner-video');

        elements.productSearch = document.getElementById('product-search');
        elements.productResults = document.getElementById('product-results');

        elements.customerSearch = document.getElementById('customer-search');
        elements.customerResults = document.getElementById('customer-results');
        elements.selectedCustomer = document.getElementById('selected-customer');
        elements.customerName = document.getElementById('customer-name');
        elements.customerPhone = document.getElementById('customer-phone');
        elements.customerPoints = document.getElementById('customer-points');
        elements.removeCustomer = document.getElementById('remove-customer');

        elements.cartItems = document.getElementById('cart-items');
        elements.cartCount = document.getElementById('cart-count');

        elements.subtotal = document.getElementById('subtotal');
        elements.totalTax = document.getElementById('total-tax');
        elements.discount = document.getElementById('discount');
        elements.grandTotal = document.getElementById('grand-total');

        elements.loyaltySection = document.getElementById('loyalty-section');
        elements.availablePoints = document.getElementById('available-points');
        elements.redeemPoints = document.getElementById('redeem-points');
        elements.applyPointsBtn = document.getElementById('apply-points-btn');

        
        elements.changeAmount = document.getElementById('change-amount');

        elements.completeBillBtn = document.getElementById('complete-bill-btn');
        elements.holdBillBtn = document.getElementById('hold-bill-btn');
        elements.clearBillBtn = document.getElementById('clear-bill-btn');
        elements.newBillBtn = document.getElementById('new-bill-btn');

        elements.heldBillsSection = document.getElementById('held-bills-section');
        elements.heldBillsList = document.getElementById('held-bills-list');

        elements.invoiceModal = document.getElementById('invoice-modal');
        elements.invoiceContent = document.getElementById('invoice-content');
        elements.invoiceClose = document.getElementById('invoice-close');
        elements.closeInvoiceBtn = document.getElementById('close-invoice-btn');
        elements.printInvoiceBtn = document.getElementById('print-invoice-btn');

        elements.upiModal = document.getElementById('upi-modal');
        elements.upiModalClose = document.getElementById('upi-modal-close');
        elements.upiAmount = document.getElementById('upi-amount');
        elements.upiStatus = document.getElementById('upi-status');
        elements.upiCancelBtn = document.getElementById('upi-cancel-btn');
        elements.upiConfirmBtn = document.getElementById('upi-confirm-btn');
        elements.razorpayPayBtn = document.getElementById('razorpay-pay-btn');

        elements.whatsappBtn = document.getElementById('whatsapp-invoice-btn');

        

        // Inside cacheElements()
elements.whatsappBtn = document.getElementById('whatsapp-invoice-btn');
elements.closeInvoiceBtn = document.getElementById('close-invoice-btn-fixed');
elements.printInvoiceBtn = document.getElementById('print-invoice-btn-fixed');
elements.invoiceCloseX = document.getElementById('invoice-close'); // The small 'x'
// STEP 10.2 — Mixed payment inputs
elements.cashAmount = document.getElementById('cash-amount');
elements.upiAmountInput = document.getElementById('upi-amount-input');
elements.remainingAmount = document.getElementById('remaining-amount');

    }

    function setupEventListeners() {


if (elements.whatsappBtn) {
    elements.whatsappBtn.addEventListener('click', () => {
        // This looks for data stored in window.currentBillForWhatsapp
        if (window.currentBillForWhatsapp) {
            sendWhatsAppBill(window.currentBillForWhatsapp);
        } else {
            Utils.showToast("No bill data found to send", "error");
        }
    });
}


        elements.cameraToggle.addEventListener('click', toggleCamera);

        elements.customerSearch.addEventListener('input', Utils.debounce(searchCustomers, 300));
        elements.customerSearch.addEventListener('focus', () => {
            if (elements.customerResults.innerHTML)
                elements.customerResults.classList.add('show');
        });

        document.addEventListener('click', (e) => {
            if (!elements.customerSearch.contains(e.target)
                && !elements.customerResults.contains(e.target)) {
                elements.customerResults.classList.remove('show');
            }
            if (elements.productSearch && elements.productResults) {
                if (!elements.productSearch.contains(e.target)
                    && !elements.productResults.contains(e.target)) {
                    elements.productResults.classList.remove('show');
                }
            }
        });

        if (elements.productSearch) {
            elements.productSearch.addEventListener('input', Utils.debounce(searchProducts, 300));
            elements.productSearch.addEventListener('focus', () => {
                if (elements.productResults.innerHTML)
                    elements.productResults.classList.add('show');
            });
        }

        elements.removeCustomer.addEventListener('click', () => {
            selectedCustomer = null;
            loyaltyPointsToRedeem = 0;
            updateCustomerUI();
            updateTotals();
        });

        elements.whatsappBtn.addEventListener('click', () => {
    // This uses the same billData we just generated in completeBill
    if (window.currentBillForWhatsapp) {
        sendWhatsAppBill(window.currentBillForWhatsapp);
    }
    else {
        Utils.showToast("No bill data found to send", "error");
    }
});

        elements.applyPointsBtn.addEventListener('click', applyLoyaltyPoints);

        

        elements.completeBillBtn.addEventListener('click', completeBill);
        elements.holdBillBtn.addEventListener('click', holdBill);
        elements.clearBillBtn.addEventListener('click', clearBill);
        elements.newBillBtn.addEventListener('click', clearBill);

        elements.invoiceClose.addEventListener('click', closeInvoiceModal);
        elements.closeInvoiceBtn.addEventListener('click', closeInvoiceModal);
        elements.printInvoiceBtn.addEventListener('click', printCurrentInvoice);

        elements.invoiceModal.addEventListener('click', e => {
            if (e.target === elements.invoiceModal) closeInvoiceModal();
        });

        if (elements.upiModal) {
            elements.upiModalClose.addEventListener('click', closeUpiModal);
            elements.upiCancelBtn.addEventListener('click', closeUpiModal);
            elements.upiConfirmBtn.addEventListener('click', confirmUpiPayment);

            elements.upiModal.addEventListener('click', e => {
                if (e.target === elements.upiModal) closeUpiModal();
            });

        }
        // Mixed payment input listeners
if (elements.cashAmount) {
    elements.cashAmount.addEventListener('input', updateChange);
}

if (elements.upiAmountInput) {
    elements.upiAmountInput.addEventListener('input', updateChange);
}

    }

    async function loadSettings() {
        try {
            const doc = await db.collection(COLLECTIONS.SETTINGS).doc('config').get();
            if (doc.exists)
                settings = { ...DEFAULT_SETTINGS, ...doc.data() };
        } catch (e) {
            console.error('Error loading settings:', e);
        }
    }

    async function toggleCamera() {
        if (!window.BarcodeScanner) return;
        await window.BarcodeScanner.toggleCamera(
            elements.scannerVideo,
            elements.cameraPreview,
            handleBarcodeScanned
        );
    }

    /** =========================
     *  PRODUCT SEARCH / CART
     * ========================= */

    async function handleBarcodeScanned(barcode) {
        try {
            const product = await findProductByBarcode(barcode);
            if (!product) return Utils.showToast(`Product not found: ${barcode}`, 'warning');

            if (product.stock <= 0)
                return Utils.showToast(`Product out of stock: ${product.name}`, 'error');

            addToCart(product);
        } catch (e) {
            console.error(e);
            Utils.showToast(ERROR_MESSAGES.GENERIC_ERROR, 'error');
        }
    }

    async function findProductByBarcode(barcode) {
        const snap = await db.collection(COLLECTIONS.PRODUCTS)
            .where('barcode', '==', barcode)
            .where('active', '==', true)
            .limit(1)
            .get();

        if (snap.empty) return null;
        const doc = snap.docs[0];
        return { id: doc.id, ...doc.data() };
    }

    async function searchProducts() {
        const q = elements.productSearch.value.trim().toLowerCase();
        if (!q || q.length < 2) {
            elements.productResults.innerHTML = '';
            elements.productResults.classList.remove('show');
            return;
        }

        try {
            const snap = await db.collection(COLLECTIONS.PRODUCTS)
                .where('active', '==', true)
                .get();

            const products = [];
            snap.forEach(doc => {
                const d = doc.data();
                if (
                    d.name.toLowerCase().includes(q) ||
                    (d.barcode && d.barcode.toLowerCase().includes(q))
                ) {
                    products.push({ id: doc.id, ...d });
                }
            });

            elements.productResults.innerHTML =
                products.length === 0
                    ? `<div class="search-result-item">No products found</div>`
                    : products.slice(0, 10).map(p => `
                        <div class="search-result-item" onclick="Billing.selectProduct('${p.id}')">
                            <strong>${Utils.sanitize(p.name)}</strong>
                            <div class="text-muted" style="font-size:12px;">
                                ${Utils.formatCurrency(p.price)} | Stock: ${p.stock} | ${Utils.sanitize(p.barcode || '')}
                            </div>
                        </div>
                    `).join('');

            elements.productResults.classList.add('show');

        } catch (e) {
            console.error('Error searching products:', e);
        }
    }

    async function selectProduct(id) {
        try {
            const doc = await db.collection(COLLECTIONS.PRODUCTS).doc(id).get();
            if (!doc.exists) return Utils.showToast('Product not found', 'error');

            const p = { id: doc.id, ...doc.data() };

            if (p.stock <= 0)
                return Utils.showToast(`Product out of stock: ${p.name}`, 'error');

            addToCart(p);
            elements.productSearch.value = '';
            elements.productResults.innerHTML = '';
            elements.productResults.classList.remove('show');
            Utils.showToast(`${p.name} added to cart`, 'success');

        } catch (e) {
            console.error(e);
            Utils.showToast(ERROR_MESSAGES.GENERIC_ERROR, 'error');
        }
    }

    function addToCart(p) {
        const item = cart.find(i => i.productId === p.id);

        if (item) {
            if (item.quantity >= p.stock)
                return Utils.showToast('Not enough stock available', 'warning');

            item.quantity++;
            item.total = item.quantity * item.unitPrice * (1 + item.tax / 100);
        } else {
            cart.push({
                productId: p.id,
                name: p.name,
                barcode: p.barcode,
                category: p.category,
                quantity: 1,
                unitPrice: p.price,
                tax: p.tax || 0,
                maxStock: p.stock,
                total: p.price * (1 + (p.tax || 0) / 100)
            });
        }

        updateCartUI();
        updateTotals();
        elements.barcodeInput?.focus();
    }

    function updateQuantity(id, delta) {
        const item = cart.find(i => i.productId === id);
        if (!item) return;

        const qty = item.quantity + delta;

        if (qty <= 0) return removeFromCart(id);
        if (qty > item.maxStock)
            return Utils.showToast('Not enough stock available', 'warning');

        item.quantity = qty;
        item.total = qty * item.unitPrice * (1 + item.tax / 100);

        updateCartUI();
        updateTotals();
    }

    function removeFromCart(id) {
        cart = cart.filter(i => i.productId !== id);
        updateCartUI();
        updateTotals();
    }

    function updateCartUI() {
        elements.cartCount.textContent =
            cart.reduce((s, i) => s + i.quantity, 0);

        if (cart.length === 0) {
            elements.cartItems.innerHTML =
                `<li class="cart-empty">Scan products to add to cart</li>`;
            elements.completeBillBtn.disabled = true;
            return;
        }

        elements.completeBillBtn.disabled = false;

        elements.cartItems.innerHTML = cart.map(i => `
            <li class="cart-item">
                <div class="cart-item-info">
                    <div class="cart-item-name">${Utils.sanitize(i.name)}</div>
                    <div class="cart-item-barcode-container">
                        <span class="cart-item-barcode-text">${Utils.sanitize(i.barcode)}</span>
                        <svg class="cart-barcode-svg" data-barcode="${Utils.sanitize(i.barcode)}"></svg>
                    </div>
                    <div class="cart-item-price">
                        ${Utils.formatCurrency(i.unitPrice)} x ${i.quantity}
                    </div>
                </div>

                <div class="quantity-control">
                    <button class="quantity-btn" onclick="Billing.updateQuantity('${i.productId}',-1)">-</button>
                    <span class="quantity-value">${i.quantity}</span>
                    <button class="quantity-btn" onclick="Billing.updateQuantity('${i.productId}',1)">+</button>
                </div>

                <div class="cart-item-total">${Utils.formatCurrency(i.total)}</div>
                <button class="cart-item-remove" onclick="Billing.removeFromCart('${i.productId}')">&times;</button>
            </li>
        `).join('');

        // Generate barcode images for cart items
        generateCartBarcodes();
    }

    /**
     * Generate barcode images for cart items using JsBarcode
     */
    function generateCartBarcodes() {
        if (typeof JsBarcode === 'undefined') {
            console.warn('JsBarcode library not loaded');
            return;
        }

        document.querySelectorAll('.cart-barcode-svg').forEach(svg => {
            const barcodeValue = svg.getAttribute('data-barcode');
            if (barcodeValue) {
                try {
                    JsBarcode(svg, barcodeValue, {
                        format: 'CODE128',
                        width: 1,
                        height: 20,
                        displayValue: false,
                        margin: 2
                    });
                } catch (error) {
                    console.error('Error generating barcode:', error);
                }
            }
        });
    }

    /** =========================
     *  TOTALS / LOYALTY
     * ========================= */

    function updateTotals() {
    const subtotal = cart.reduce((s, i) => s + i.quantity * i.unitPrice, 0);
    const totalTax = cart.reduce((s, i) => s + (i.quantity * i.unitPrice * i.tax / 100), 0);

    let loyaltyDiscount = 0;
    if (selectedCustomer && loyaltyPointsToRedeem > 0)
        loyaltyDiscount = loyaltyPointsToRedeem * (settings.loyaltyRedemptionValue || 0.5);

    const grandTotal = Math.max(0, subtotal + totalTax - loyaltyDiscount);

    elements.subtotal.textContent = Utils.formatCurrency(subtotal);
    elements.totalTax.textContent = Utils.formatCurrency(totalTax);
    elements.discount.textContent = `- ${Utils.formatCurrency(loyaltyDiscount)}`;
    elements.grandTotal.textContent = Utils.formatCurrency(grandTotal);

    updateChange();
}

/* 👇 ADD THIS EXACTLY HERE 👇 */
function getGrandTotalValue() {
    return parseFloat(
        elements.grandTotal.textContent.replace(/[^0-9.-]+/g, '')
    ) || 0;
}

function updateChange() {
    const total = getGrandTotalValue();

    const cash = parseFloat(elements.cashAmount?.value) || 0;
    const upi = parseFloat(elements.upiAmountInput?.value) || 0;

    const paid = cash + upi;
    const change = paid - total;

    elements.changeAmount.textContent =
        Utils.formatCurrency(Math.max(0, change));

    elements.changeAmount.style.color =
        change >= 0 ? '#10B981' : '#EF4444';

    const remaining = Math.max(0, total - paid);
    if (elements.remainingAmount) {
        elements.remainingAmount.textContent =
            Utils.formatCurrency(remaining);
    }
}



    /** =========================
     *  CUSTOMER & LOYALTY
     * ========================= */

    async function searchCustomers() {
        const q = elements.customerSearch.value.trim().toLowerCase();

        if (!q || q.length < 2) {
            elements.customerResults.innerHTML = '';
            elements.customerResults.classList.remove('show');
            return;
        }

        const snap = await db.collection(COLLECTIONS.CUSTOMERS)
            .where('active', '!=', false)
            .limit(10)
            .get();

        const results = [];
        snap.forEach(doc => {
            const c = { id: doc.id, ...doc.data() };
            if (c.phone?.includes(q) || c.name?.toLowerCase().includes(q))
                results.push(c);
        });

        elements.customerResults.innerHTML =
            results.length === 0
                ? `<div class="customer-search-item"><span>No customers found</span></div>`
                : results.map(c => `
                    <div class="customer-search-item" onclick="Billing.selectCustomer('${c.id}')">
                        <div class="name">${Utils.sanitize(c.name)}</div>
                        <div class="phone">${Utils.sanitize(c.phone)} | ${c.loyaltyPoints || 0} pts</div>
                    </div>
                `).join('');

        elements.customerResults.classList.add('show');
    }

    async function selectCustomer(id) {
        const doc = await db.collection(COLLECTIONS.CUSTOMERS).doc(id).get();
        if (!doc.exists) return;

        selectedCustomer = { id: doc.id, ...doc.data() };
        loyaltyPointsToRedeem = 0;

        updateCustomerUI();
        updateTotals();

        elements.customerSearch.value = '';
        elements.customerResults.classList.remove('show');
    }

    function updateCustomerUI() {
        if (!selectedCustomer) {
            elements.selectedCustomer.style.display = 'none';
            elements.loyaltySection.style.display = 'none';
            return;
        }

        elements.customerName.textContent = selectedCustomer.name;
        elements.customerPhone.textContent = selectedCustomer.phone;
        elements.customerPoints.textContent = `${selectedCustomer.loyaltyPoints || 0} pts`;
        elements.selectedCustomer.style.display = 'flex';

        if (settings.loyaltyEnabled && (selectedCustomer.loyaltyPoints || 0) > 0) {
            elements.loyaltySection.style.display = 'block';
            elements.availablePoints.textContent = selectedCustomer.loyaltyPoints;
            elements.redeemPoints.max = selectedCustomer.loyaltyPoints;
        } else {
            elements.loyaltySection.style.display = 'none';
        }
    }

    function applyLoyaltyPoints() {
        if (!selectedCustomer) return;

        const pts = parseInt(elements.redeemPoints.value) || 0;
        const max = selectedCustomer.loyaltyPoints || 0;

        if (pts > max)
            return Utils.showToast('Not enough points available', 'warning');

        loyaltyPointsToRedeem = pts;
        updateTotals();
        Utils.showToast(`Applied ${pts} loyalty points`, 'success');
    }

    /** =========================
     *  COMPLETE BILL
     * ========================= */

    async function completeBill() {
        if (cart.length === 0)
            return Utils.showToast('Cart is empty', 'warning');
        // STEP 9.1: reset payment breakup for this bill
        paymentBreakup.cash = 0;
        paymentBreakup.upi = 0;


        const paymentMode = document.querySelector('input[name="payment-mode"]:checked').value;

        const grandTotal = parseFloat(elements.grandTotal.textContent.replace(/[^0-9.-]+/g, '')) || 0;
        let amountPaid = 0;




        if (paymentMode === 'UPI') {
    paymentBreakup.upi = grandTotal; // full UPI for now
    amountPaid = paymentBreakup.upi;
}



       const totalPaid =
    (parseFloat(elements.cashAmount?.value) || 0) +
    (parseFloat(elements.upiAmountInput?.value) || 0);

if (totalPaid < grandTotal && !selectedCustomer) {
    return Utils.showToast(
        'Full payment not received. Select customer for due.',
        'warning'
    );
}





function sendWhatsAppBill(data) {
    const phone = selectedCustomer ? selectedCustomer.phone : '';
    
    if (!phone || phone.length < 10) {
        Utils.showToast("Please select a customer with a valid phone number", "warning");
        return;
    }

    // Format items for the message
    const itemsText = data.items.map(i => 
        `• ${i.name} (${i.quantity} x ${Utils.formatCurrency(i.unitPrice)})`
    ).join('%0A'); // %0A is a URL-encoded newline

    const businessName = settings.storeName || "Our Store";
    
    // Construct the message
    const message = `*Invoice from ${businessName}*%0A%0A` +
        `Hi ${data.customerName},%0A` +
        `Your bill *${data.billNumber}* is ready.%0A%0A` +
        `*Items:*%0A${itemsText}%0A%0A` +
        `*Total Amount: ${Utils.formatCurrency(data.grandTotal)}*%0A` +
        `Payment Mode: ${data.paymentMode}%0A%0A` +
        `Thank you for shopping with us!`;

    // Indian country code (91) is added. Change if operating elsewhere.
    const whatsappUrl = `https://wa.me/91${phone}?text=${message}`;
    
    window.open(whatsappUrl, '_blank');
}


        elements.completeBillBtn.disabled = true;
        elements.completeBillBtn.innerHTML = '<span class="spinner"></span> Processing...';

        try {
            const counterRef = db.collection('COUNTERS').doc('billNumber');

            const billNumber = await db.runTransaction(async (tx) => {
                const doc = await tx.get(counterRef);

                const today = Utils.formatDate(new Date(), false).split(' ')[0]; // YYYY-MM-DD
                let sequence = 1;

                if (!doc.exists) {
                    tx.set(counterRef, { lastDate: today, sequence: 1 });
                } else {
                    const data = doc.data();
                    if (data.lastDate === today) {
                        sequence = (data.sequence || 0) + 1;
                        tx.update(counterRef, { sequence });
                    } else {
                        sequence = 1;
                        tx.update(counterRef, { lastDate: today, sequence: 1 });
                    }
                }

                const seqStr = String(sequence).padStart(4, '0');
                return `BILL-${today.replace(/-/g, '')}-${seqStr}`;
            });


            const subtotal = cart.reduce((s, i) => s + i.quantity * i.unitPrice, 0);
            const totalTax = cart.reduce((s, i) => s + (i.quantity * i.unitPrice * i.tax / 100), 0);
            const loyaltyDiscount = loyaltyPointsToRedeem * (settings.loyaltyRedemptionValue || 0.5);
            paymentBreakup.cash = parseFloat(elements.cashAmount?.value) || 0;
            paymentBreakup.upi = parseFloat(elements.upiAmountInput?.value) || 0;

            const amountPaid = paymentBreakup.cash + paymentBreakup.upi;

            const dueAmount = Math.max(0, grandTotal - amountPaid);

            const pointsEarned = Math.floor(grandTotal / (settings.loyaltyPointsPerRupee || 10));

            const billData = {
                billNumber,
                customerId: selectedCustomer?.id || null,
                items: cart.map(i => ({
                    productId: i.productId,
                    name: i.name,
                    barcode: i.barcode,
                    category: i.category,
                    quantity: i.quantity,
                    unitPrice: i.unitPrice,
                    tax: i.tax,
                    total: i.total
                })),
                subtotal,
                totalTax,
                discount: loyaltyDiscount,
                loyaltyPointsUsed: loyaltyPointsToRedeem,
                loyaltyPointsEarned: selectedCustomer ? pointsEarned : 0,
                grandTotal,
                amountPaid,
                dueAmount,
                paymentMode,
                paymentBreakup: {
                cash: paymentBreakup.cash,
                upi: paymentBreakup.upi
                },

                billedBy: currentUser.id,
                status: BILL_STATUS.COMPLETED,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            };

            const batch = db.batch();
            const billRef = db.collection(COLLECTIONS.BILLS).doc();
            batch.set(billRef, billData);

            for (const i of cart) {
                const productRef = db.collection(COLLECTIONS.PRODUCTS).doc(i.productId);
                batch.update(productRef, {
                    stock: firebase.firestore.FieldValue.increment(-i.quantity),
                    updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                });

                const logRef = db.collection(COLLECTIONS.INVENTORY_LOGS).doc();
                batch.set(logRef, {
                    productId: i.productId,
                    change: -i.quantity,
                    reason: INVENTORY_REASONS.BILLING,
                    notes: `Bill: ${billNumber}`,
                    performedBy: currentUser.id,
                    createdAt: firebase.firestore.FieldValue.serverTimestamp()
                });
            }

            if (selectedCustomer) {
                const customerRef = db.collection(COLLECTIONS.CUSTOMERS).doc(selectedCustomer.id);
                const netPoints = pointsEarned - loyaltyPointsToRedeem;

                batch.update(customerRef, {
                    loyaltyPoints: firebase.firestore.FieldValue.increment(netPoints),
                    totalSpent: firebase.firestore.FieldValue.increment(grandTotal),
                    updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                });

                if (loyaltyPointsToRedeem > 0) {
                    const debitRef = db.collection(COLLECTIONS.LOYALTY_LOGS).doc();
                    batch.set(debitRef, {
                        customerId: selectedCustomer.id,
                        billId: billRef.id,
                        type: LOYALTY_TYPES.DEBIT,
                        points: loyaltyPointsToRedeem,
                        reason: `Redeemed for bill ${billNumber}`,
                        createdAt: firebase.firestore.FieldValue.serverTimestamp()
                    });
                }

                if (pointsEarned > 0) {
                    const creditRef = db.collection(COLLECTIONS.LOYALTY_LOGS).doc();
                    batch.set(creditRef, {
                        customerId: selectedCustomer.id,
                        billId: billRef.id,
                        type: LOYALTY_TYPES.CREDIT,
                        points: pointsEarned,
                        reason: `Earned from bill ${billNumber}`,
                        createdAt: firebase.firestore.FieldValue.serverTimestamp()
                    });
                }

                if (dueAmount > 0) {
                    const dueRef = db.collection(COLLECTIONS.DUES).doc();
                    batch.set(dueRef, {
                        customerId: selectedCustomer.id,
                        billId: billRef.id,
                        originalAmount: dueAmount,
                        remainingAmount: dueAmount,
                        status: DUE_STATUS.PENDING,
                        payments: [],
                        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                    });

                    batch.update(customerRef, {
                        totalDues: firebase.firestore.FieldValue.increment(dueAmount)
                    });
                }
            }


            // Inside completeBill() near the end
billData.customerName = selectedCustomer?.name || 'Walk-in Customer';
billData.customerPhone = selectedCustomer?.phone || ''; // Keep phone for WhatsApp
billData.invoiceDate = new Date();

// SAVE THIS FOR THE WHATSAPP BUTTON
window.currentBillForWhatsapp = billData; 

// Near the end of the completeBill function, after saving to Firestore
const finalData = { 
    ...billData, 
    customerName: selectedCustomer?.name || 'Valued Customer',
    customerPhone: selectedCustomer?.phone || '' 
};

// This line makes the data available to the WhatsApp button
window.currentBillForWhatsapp = finalData; 

showInvoice(finalData);


showInvoice(billData);

            await batch.commit();

            billData.customerName = selectedCustomer?.name || 'Walk-in Customer';
            billData.invoiceDate = new Date();
            showInvoice(billData);

            Utils.showToast(SUCCESS_MESSAGES.BILL_COMPLETED, 'success');
            clearBill();

        } catch (e) {
            console.error('Error completing bill:', e);
            Utils.showToast(ERROR_MESSAGES.GENERIC_ERROR, 'error');
        }

        elements.completeBillBtn.disabled = false;
        elements.completeBillBtn.textContent = 'Complete Bill';
    }

    /** =========================
     *  INVOICE / UPI / HELD BILLS
     * ========================= */

    function showInvoice(data) {
        const html = window.Invoice.generate(data, settings);
        window.Invoice.display(html, elements.invoiceContent);
        elements.invoiceModal.classList.add('active');
    }

    function closeInvoiceModal() {
        elements.invoiceModal.classList.remove('active');
    }

    function printCurrentInvoice() {
        window.Invoice.print(elements.invoiceContent.innerHTML);
    }

    // Razorpay configuration
    const RAZORPAY_KEY = 'rzp_test_S1efgWrw8U4lkT';
    let currentPaymentAmount = 0;

    function openUpiModal(amount) {
        if (!elements.upiModal) return;
        currentPaymentAmount = amount;
        elements.upiAmount.textContent = Utils.formatCurrency(amount);
        elements.upiStatus.innerHTML = '<span class="status-pending">Click the button below to pay</span>';
        elements.upiModal.classList.add('active');

        // Setup Razorpay button listener
        if (elements.razorpayPayBtn) {
            elements.razorpayPayBtn.onclick = initiateRazorpayPayment;
        }
    }

    function initiateRazorpayPayment() {
        if (typeof Razorpay === 'undefined') {
            Utils.showToast('Razorpay SDK not loaded', 'error');
            return;
        }

        const amountInPaise = Math.round(currentPaymentAmount * 100);

        const options = {
            key: RAZORPAY_KEY,
            amount: amountInPaise,
            currency: 'INR',
            name: 'Zure Stores',
            description: 'Bill Payment',
            handler: function (response) {
                // Payment successful
                elements.upiStatus.innerHTML = '<span class="status-success">✓ Payment successful!</span>';
                Utils.showToast('Payment successful! ID: ' + response.razorpay_payment_id, 'success');
                setTimeout(() => {
                    closeUpiModal();
                }, 1500);
            },
            prefill: {
                name: selectedCustomer?.name || '',
                contact: selectedCustomer?.phone || ''
            },
            theme: {
                color: '#0EA5E9'
            },
            modal: {
                ondismiss: function () {
                    elements.upiStatus.innerHTML = '<span class="status-pending">Payment cancelled. Try again.</span>';
                }
            }
        };

        const rzp = new Razorpay(options);
        rzp.on('payment.failed', function (response) {
            Utils.showToast('Payment failed: ' + response.error.description, 'error');
            elements.upiStatus.innerHTML = '<span class="status-error">✗ Payment failed</span>';
        });
        rzp.open();
    }

    function closeUpiModal() {
        elements.upiModal?.classList.remove('active');
        currentPaymentAmount = 0;
    }

    function confirmUpiPayment() {
        // This is now handled by Razorpay handler
        initiateRazorpayPayment();
    }

    function holdBill() {
        if (cart.length === 0)
            return Utils.showToast('Cart is empty', 'warning');

        const heldBill = {
            id: Date.now().toString(),
            cart: [...cart],
            customer: selectedCustomer,
            timestamp: new Date().toISOString()
        };

        heldBills.push(heldBill);
        saveHeldBills();
        updateHeldBillsUI();

        Utils.showToast('Bill held successfully', 'success');
        clearBill();
    }

    function resumeBill(id) {
        const bill = heldBills.find(b => b.id === id);
        if (!bill) return;

        cart = [...bill.cart];
        selectedCustomer = bill.customer;

        heldBills = heldBills.filter(b => b.id !== id);
        saveHeldBills();
        updateHeldBillsUI();

        updateCartUI();
        updateCustomerUI();
        updateTotals();

        Utils.showToast('Bill resumed', 'success');
    }

    function removeHeldBill(id) {
        heldBills = heldBills.filter(b => b.id !== id);
        saveHeldBills();
        updateHeldBillsUI();
    }

    function saveHeldBills() {
        localStorage.setItem('heldBills', JSON.stringify(heldBills));
    }

    function loadHeldBills() {
        try {
            heldBills = JSON.parse(localStorage.getItem('heldBills') || '[]');
        } catch {
            heldBills = [];
        }
        updateHeldBillsUI();
    }

    function updateHeldBillsUI() {
        if (heldBills.length === 0) {
            elements.heldBillsSection.style.display = 'none';
            return;
        }

        elements.heldBillsSection.style.display = 'block';
        elements.heldBillsList.innerHTML = heldBills.map(b => {
            const count = b.cart.reduce((s, i) => s + i.quantity, 0);
            return `
                <div class="held-bill-chip" onclick="Billing.resumeBill('${b.id}')">
                    <span>${count} items</span>
                    <span class="remove"
                          onclick="event.stopPropagation(); Billing.removeHeldBill('${b.id}')">&times;</span>
                </div>
            `;
        }).join('');
    }

    function clearBill() {
        cart = [];
        selectedCustomer = null;
        loyaltyPointsToRedeem = 0;

        elements.customerSearch.value = '';
        
        if (elements.redeemPoints) elements.redeemPoints.value = '';

        const cashRadio = document.querySelector('input[name="payment-mode"][value="CASH"]');
        if (cashRadio) cashRadio.checked = true;

        updateCartUI();
        updateCustomerUI();
        updateTotals();
        elements.barcodeInput?.focus();
    }

    document.addEventListener('DOMContentLoaded', init);

    window.Billing = {
        init,
        addToCart,
        updateQuantity,
        removeFromCart,
        selectCustomer,
        selectProduct,
        resumeBill,
        removeHeldBill
    };


function sendWhatsAppBill(data) {
    const phone = data.customerPhone || "";
    
    if (!phone || phone.length < 10) {
        Utils.showToast("Cannot send: Walk-in customer or invalid phone number", "warning");
        return;
    }

    // Format the items list for the text message
    const itemsText = data.items.map(i => 
        `• ${i.name} (${i.quantity} x ₹${i.unitPrice})`
    ).join('%0A'); // URL-encoded newline

    const businessName = settings.storeName || "Our Store";
    
    // Construct the WhatsApp message URL
    const message = `*Invoice from ${businessName}*%0A%0A` +
        `Hi ${data.customerName},%0A` +
        `Your bill *${data.billNumber}* is ready.%0A%0A` +
        `*Items:*%0A${itemsText}%0A%0A` +
        `*Total Amount: ₹${data.grandTotal.toFixed(2)}*%0A` +
        `Payment Mode: ${data.paymentMode}%0A%0A` +
        `Thank you for shopping with us!`;

    // Indian country code (91) is added prefix to the phone number
    const whatsappUrl = `https://wa.me/91${phone}?text=${message}`;
    
    window.open(whatsappUrl, '_blank');
}


})();
