/**
 * Customer Management
 * Inventory Management System
 * 
 * Handles customer CRUD and profile management.
 */

(function () {
    'use strict';

    const { COLLECTIONS, ERROR_MESSAGES, SUCCESS_MESSAGES } = window.APP_CONSTANTS || {};

    let db = null;
    let currentUser = null;
    let allCustomers = [];
    let unsubscribe = null;

    // DOM Elements
    const elements = {};

    /**
     * Initialize customers page
     */
    async function init() {
        // Check auth
        currentUser = await window.Guards.requireStaff();
        if (!currentUser) return;

        // Update user info
        if (window.App && window.App.updateUserInfo) {
            window.App.updateUserInfo(currentUser);
        }

        // Show admin nav if admin
        if (currentUser.role === 'ADMIN') {
            document.querySelectorAll('.nav-admin-only').forEach(el => el.style.display = 'block');
        }

        db = firebase.firestore();

        // Cache DOM elements
        cacheElements();

        // Setup event listeners
        setupEventListeners();

        // Load customers
        loadCustomers();
    }

    /**
     * Cache DOM elements
     */
    function cacheElements() {
        elements.customersTable = document.getElementById('customers-table');
        elements.customerCount = document.getElementById('customer-count');
        elements.searchInput = document.getElementById('search-input');
        elements.duesFilter = document.getElementById('dues-filter');
        elements.addCustomerBtn = document.getElementById('add-customer-btn');
        elements.customerModal = document.getElementById('customer-modal');
        elements.customerForm = document.getElementById('customer-form');
        elements.modalTitle = document.getElementById('modal-title');
        elements.modalClose = document.getElementById('modal-close');
        elements.cancelBtn = document.getElementById('cancel-btn');
        elements.saveBtn = document.getElementById('save-btn');
        elements.customerId = document.getElementById('customer-id');
        elements.customerName = document.getElementById('customer-name');
        elements.customerPhone = document.getElementById('customer-phone');
        elements.customerEmail = document.getElementById('customer-email');
        elements.customerAddress = document.getElementById('customer-address');
        elements.detailsModal = document.getElementById('details-modal');
        elements.customerDetails = document.getElementById('customer-details');
        elements.detailsClose = document.getElementById('details-close');
        elements.closeDetailsBtn = document.getElementById('close-details-btn');
    }

    /**
     * Setup event listeners
     */
    function setupEventListeners() {
        // Add customer button
        elements.addCustomerBtn.addEventListener('click', () => openModal());

        // Modal close buttons
        elements.modalClose.addEventListener('click', closeModal);
        elements.cancelBtn.addEventListener('click', closeModal);
        elements.customerModal.addEventListener('click', (e) => {
            if (e.target === elements.customerModal) closeModal();
        });

        // Details modal
        elements.detailsClose.addEventListener('click', closeDetailsModal);
        elements.closeDetailsBtn.addEventListener('click', closeDetailsModal);
        elements.detailsModal.addEventListener('click', (e) => {
            if (e.target === elements.detailsModal) closeDetailsModal();
        });

        // Form submit
        elements.customerForm.addEventListener('submit', handleFormSubmit);

        // Filters
        elements.searchInput.addEventListener('input', Utils.debounce(filterCustomers, 300));
        elements.duesFilter.addEventListener('change', filterCustomers);
    }

    /**
     * Load customers with real-time updates
     */
    function loadCustomers() {
        if (unsubscribe) unsubscribe();

        // Simplified query without orderBy to avoid composite index requirement
        unsubscribe = db.collection(COLLECTIONS.CUSTOMERS)
            .onSnapshot((snapshot) => {
                allCustomers = [];
                snapshot.forEach(doc => {
                    const data = doc.data();
                    // Only include active customers
                    if (data.active !== false) {
                        allCustomers.push({ id: doc.id, ...data });
                    }
                });

                // Sort client-side by name
                allCustomers.sort((a, b) => {
                    const nameA = (a.name || '').toLowerCase();
                    const nameB = (b.name || '').toLowerCase();
                    return nameA.localeCompare(nameB);
                });

                filterCustomers();
            }, (error) => {
                console.error('Error loading customers:', error);
                elements.customersTable.innerHTML = '<tr><td colspan="6" class="text-center text-error">Error loading customers</td></tr>';
            });
    }

    /**
     * Filter and display customers
     */
    function filterCustomers() {
        const searchTerm = elements.searchInput.value.toLowerCase().trim();
        const duesFilter = elements.duesFilter.value;

        let filtered = allCustomers.filter(customer => {
            // Search filter
            const matchesSearch = !searchTerm ||
                customer.name.toLowerCase().includes(searchTerm) ||
                customer.phone.includes(searchTerm);

            // Dues filter
            let matchesDues = true;
            if (duesFilter === 'withDues') {
                matchesDues = (customer.totalDues || 0) > 0;
            } else if (duesFilter === 'noDues') {
                matchesDues = (customer.totalDues || 0) === 0;
            }

            return matchesSearch && matchesDues;
        });

        renderCustomers(filtered);
    }

    /**
     * Render customers table
     */
/**
 * Updated Render function in customers.js
 */
function renderCustomers(customers) {
    if (customers.length === 0) {
        elements.customersTable.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No customers found</td></tr>';
        elements.customerCount.textContent = 'No customers to display';
        return;
    }

    const html = customers.map(customer => {
        const hasDues = (customer.totalDues || 0) > 0;

        return `
            <tr>
                <td>${Utils.sanitize(customer.name)}</td>
                <td>${Utils.sanitize(customer.phone)}</td>
                <td><span class="badge badge-info">${customer.loyaltyPoints || 0} pts</span></td>
                <td>${Utils.formatCurrency(customer.totalSpent || 0)}</td>
                <td class="${hasDues ? 'text-error' : ''}">${Utils.formatCurrency(customer.totalDues || 0)}</td>
                <td>
                    <div class="action-buttons">
                        <button class="action-btn action-btn-edit" onclick="Customers.editCustomer('${customer.id}')">Edit</button>
                        <button class="action-btn" 
                                style="background-color: var(--error-color, #ef4444); color: white; border: none;" 
                                onclick="Customers.deleteCustomer('${customer.id}')">
                            Delete
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');

    elements.customersTable.innerHTML = html;
    elements.customerCount.textContent = `Showing ${customers.length} of ${allCustomers.length} customers`;
}


/**
 * Soft delete customer
 */
async function deleteCustomer(customerId) {
    const customer = allCustomers.find(c => c.id === customerId);
    if (!customer) return;

    // Safety check: Don't delete if they owe money
    if ((customer.totalDues || 0) > 0) {
        return Utils.showToast('Cannot delete customer with pending dues', 'error');
    }

    const confirmed = await Utils.showConfirm(
        `Are you sure you want to delete ${customer.name}? This will hide them from billing but keep their history.`,
        'Delete',
        'Cancel'
    );

    if (!confirmed) return;

    try {
        await db.collection(COLLECTIONS.CUSTOMERS).doc(customerId).update({
            active: false,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        Utils.showToast(SUCCESS_MESSAGES.CUSTOMER_DELETED || 'Customer removed', 'success');
    } catch (error) {
        console.error('Error deleting customer:', error);
        Utils.showToast(ERROR_MESSAGES.GENERIC_ERROR, 'error');
    }
}

    /**
     * Open modal for add/edit
     */
    function openModal(customer = null) {
        elements.customerForm.reset();
        clearErrors();

        if (customer) {
            elements.modalTitle.textContent = 'Edit Customer';
            elements.customerId.value = customer.id;
            elements.customerName.value = customer.name;
            elements.customerPhone.value = customer.phone;
            elements.customerEmail.value = customer.email || '';
            elements.customerAddress.value = customer.address || '';
            elements.customerPhone.disabled = true; // Phone is unique, don't allow edit
        } else {
            elements.modalTitle.textContent = 'Add Customer';
            elements.customerId.value = '';
            elements.customerPhone.disabled = false;
        }

        elements.customerModal.classList.add('active');
        elements.customerName.focus();
    }

    /**
     * Close modal
     */
    function closeModal() {
        elements.customerModal.classList.remove('active');
        elements.customerForm.reset();
        clearErrors();
    }

    /**
     * Clear form errors
     */
    function clearErrors() {
        document.querySelectorAll('.form-error').forEach(el => el.textContent = '');
        document.querySelectorAll('.form-input.error').forEach(el => el.classList.remove('error'));
    }

    /**
     * Handle form submit
     */
    async function handleFormSubmit(e) {
        e.preventDefault();

        if (!validateForm()) return;

        elements.saveBtn.disabled = true;
        elements.saveBtn.innerHTML = '<span class="spinner"></span> Saving...';

        const customerId = elements.customerId.value;
        const customerData = {
            name: elements.customerName.value.trim(),
            email: elements.customerEmail.value.trim() || null,
            address: elements.customerAddress.value.trim() || null,
            active: true,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        };

        try {
            if (customerId) {
                // Update existing customer
                await db.collection(COLLECTIONS.CUSTOMERS).doc(customerId).update(customerData);
                Utils.showToast(SUCCESS_MESSAGES.CUSTOMER_UPDATED, 'success');
            } else {
                // Check phone uniqueness
                const phone = elements.customerPhone.value.trim();
                const phoneExists = await checkPhoneExists(phone);
                if (phoneExists) {
                    document.getElementById('phone-error').textContent = ERROR_MESSAGES.CUSTOMER_PHONE_EXISTS;
                    elements.customerPhone.classList.add('error');
                    elements.saveBtn.disabled = false;
                    elements.saveBtn.textContent = 'Save Customer';
                    return;
                }

                // Add new customer
                customerData.phone = phone;
                customerData.loyaltyPoints = 0;
                customerData.totalSpent = 0;
                customerData.totalDues = 0;
                customerData.createdAt = firebase.firestore.FieldValue.serverTimestamp();

                await db.collection(COLLECTIONS.CUSTOMERS).add(customerData);
                Utils.showToast(SUCCESS_MESSAGES.CUSTOMER_ADDED, 'success');
            }

            closeModal();
        } catch (error) {
            console.error('Error saving customer:', error);
            Utils.showToast(ERROR_MESSAGES.GENERIC_ERROR, 'error');
        }

        elements.saveBtn.disabled = false;
        elements.saveBtn.textContent = 'Save Customer';
    }

    /**
     * Validate form
     */
    function validateForm() {
        let isValid = true;
        clearErrors();

        // Name validation
        if (!elements.customerName.value.trim()) {
            document.getElementById('name-error').textContent = 'Name is required';
            elements.customerName.classList.add('error');
            isValid = false;
        }

        // Phone validation (only for new customers)
        if (!elements.customerId.value) {
            const phone = elements.customerPhone.value.trim();
            if (!phone) {
                document.getElementById('phone-error').textContent = 'Phone number is required';
                elements.customerPhone.classList.add('error');
                isValid = false;
            } else if (!Utils.isValidPhone(phone)) {
                document.getElementById('phone-error').textContent = 'Please enter a valid 10-digit phone number';
                elements.customerPhone.classList.add('error');
                isValid = false;
            }
        }

        return isValid;
    }

    /**
     * Check if phone already exists
     */
    async function checkPhoneExists(phone) {
        const snapshot = await db.collection(COLLECTIONS.CUSTOMERS)
            .where('phone', '==', phone)
            .limit(1)
            .get();

        return !snapshot.empty;
    }

    /**
     * Edit customer
     */
    function editCustomer(customerId) {
        const customer = allCustomers.find(c => c.id === customerId);
        if (customer) {
            openModal(customer);
        }
    }

    /**
     * View customer details
     */
    async function viewDetails(customerId) {
        const customer = allCustomers.find(c => c.id === customerId);
        if (!customer) return;

        // Load purchase history
        let purchaseHistory = [];
        try {
            const billsSnapshot = await db.collection(COLLECTIONS.BILLS)
                .where('customerId', '==', customerId)
                .orderBy('createdAt', 'desc')
                .limit(10)
                .get();

            billsSnapshot.forEach(doc => {
                purchaseHistory.push({ id: doc.id, ...doc.data() });
            });
        } catch (error) {
            console.error('Error loading purchase history:', error);
        }

        const detailsHtml = `
            <div class="customer-profile">
                <div class="profile-header">
                    <div class="profile-avatar">${customer.name.charAt(0).toUpperCase()}</div>
                    <div class="profile-info">
                        <h3>${Utils.sanitize(customer.name)}</h3>
                        <p>${Utils.sanitize(customer.phone)}</p>
                        ${customer.email ? `<p>${Utils.sanitize(customer.email)}</p>` : ''}
                    </div>
                </div>
                
                <div class="stats-grid mb-md" style="grid-template-columns: repeat(3, 1fr);">
                    <div class="stat-card">
                        <div class="stat-label">Loyalty Points</div>
                        <div class="stat-value">${customer.loyaltyPoints || 0}</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-label">Total Spent</div>
                        <div class="stat-value">${Utils.formatCurrency(customer.totalSpent || 0)}</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-label">Pending Dues</div>
                        <div class="stat-value ${(customer.totalDues || 0) > 0 ? 'text-error' : ''}">${Utils.formatCurrency(customer.totalDues || 0)}</div>
                    </div>
                </div>
                
                <h4 class="mb-sm">Recent Purchases</h4>
                ${purchaseHistory.length > 0 ? `
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Bill No.</th>
                                    <th>Amount</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${purchaseHistory.map(bill => `
                                    <tr>
                                        <td>${Utils.sanitize(bill.billNumber)}</td>
                                        <td>${Utils.formatCurrency(bill.grandTotal)}</td>
                                        <td>${Utils.formatDate(bill.createdAt, true)}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                ` : '<p class="text-muted">No purchase history yet</p>'}
            </div>
        `;

        elements.customerDetails.innerHTML = detailsHtml;
        elements.detailsModal.classList.add('active');
    }

    /**
     * Close details modal
     */
    function closeDetailsModal() {
        elements.detailsModal.classList.remove('active');
    }

    // Cleanup on page unload
    window.addEventListener('beforeunload', () => {
        if (unsubscribe) unsubscribe();
    });

    // Initialize when DOM is ready
    document.addEventListener('DOMContentLoaded', init);

    // Export for global access
    window.Customers = {
        init,
        editCustomer,
        viewDetails
    };


    // Update the export at the bottom of the file
window.Customers = {
    init,
    editCustomer,
    deleteCustomer // Add this here
};
})();
