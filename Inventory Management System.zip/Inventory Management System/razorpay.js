const Razorpay = require("razorpay");

const razorpay = new Razorpay({
  key_id: "rzp_test_S1efgWrw8U4lkT",
  key_secret: "7B86whJeYSOTG0LPklZ3NItl",
});

module.exports = razorpay;
