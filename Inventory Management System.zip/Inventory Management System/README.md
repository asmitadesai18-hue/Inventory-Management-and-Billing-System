# Inventory Management System

A web-based Inventory Management and POS System for small to medium grocery stores.

## Technology Stack

- **Frontend**: HTML, CSS, JavaScript (Vanilla)
- **Database**: Firebase Firestore
- **Authentication**: Firebase Auth (Email/Password)
- **Hosting**: Vercel

## Features

- Role-based access control (Admin, Staff, Customer)
- Product Management with barcode support
- Real-time Inventory Tracking
- POS Billing with barcode scanning
- Customer Management with purchase history
- Loyalty Points System
- Reports and Analytics Dashboard

## Setup Instructions

### 1. Firebase Project Setup

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Create a new project or select an existing one
3. Enable the following services:
   - **Authentication**: Enable Email/Password provider
   - **Firestore Database**: Create database in production mode

### 2. Configure Firebase

1. In Firebase Console, go to Project Settings > General
2. Scroll to "Your apps" section
3. Click "Add app" and select Web (</>)
4. Copy the configuration object
5. Update `assets/js/firebase/firebase-config.js` with your config values

### 3. Set Firestore Security Rules

1. In Firebase Console, go to Firestore Database > Rules
2. Add the following security rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    function getUserRole() {
      return get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role;
    }
    
    function isAuthenticated() {
      return request.auth != null;
    }
    
    function isAdmin() {
      return isAuthenticated() && getUserRole() == 'ADMIN';
    }
    
    function isStaffOrAdmin() {
      return isAuthenticated() && (getUserRole() == 'ADMIN' || getUserRole() == 'STAFF');
    }
    
    match /users/{userId} {
      allow read: if isAuthenticated();
      allow create: if isAuthenticated() && (isAdmin() || request.auth.uid == userId);
      allow update, delete: if isAdmin();
    }
    
    match /products/{productId} {
      allow read: if isAuthenticated();
      allow write: if isAdmin();
    }
    
    match /inventoryLogs/{logId} {
      allow read: if isAdmin();
      allow create: if isStaffOrAdmin();
      allow update, delete: if isAdmin();
    }
    
    match /customers/{customerId} {
      allow read: if isAuthenticated();
      allow write: if isStaffOrAdmin();
    }
    
    match /bills/{billId} {
      allow read: if isAuthenticated();
      allow create: if isStaffOrAdmin();
      allow update, delete: if isAdmin();
    }
    
    match /dues/{dueId} {
      allow read, write: if isStaffOrAdmin();
    }
    
    match /loyaltyLogs/{logId} {
      allow read: if isAuthenticated();
      allow create: if isStaffOrAdmin();
      allow update, delete: if isAdmin();
    }
    
    match /settings/{settingId} {
      allow read: if isAuthenticated();
      allow write: if isAdmin();
    }
  }
}
```

3. Click "Publish" to save the rules

### 4. Local Development

You can run the project locally using any static file server:

```bash
# Using Python
cd public
python -m http.server 8000

# Using Node.js (npx)
npx serve public

# Using PHP
php -S localhost:8000 -t public
```

Then open http://localhost:8000 in your browser.

### 5. Deploy to Vercel

**Option A: Using Vercel CLI**
```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel
```

**Option B: Using GitHub**
1. Push your code to GitHub
2. Go to [Vercel Dashboard](https://vercel.com/dashboard)
3. Click "New Project" and import your repository
4. Vercel will auto-detect the `vercel.json` configuration
5. Click "Deploy"

## Project Structure

```
Shreyas-9577562020-SGI/
├── public/                  # All web files (served by Vercel)
│   ├── index.html           # Landing page
│   ├── login.html           # Login page
│   ├── register.html        # Registration page
│   ├── admin/               # Admin pages
│   │   ├── dashboard.html
│   │   ├── products.html
│   │   ├── inventory.html
│   │   ├── reports.html
│   │   ├── settings.html
│   │   └── users.html
│   ├── staff/               # Staff pages
│   │   ├── billing.html
│   │   ├── customers.html
│   │   └── dues.html
│   └── assets/              # Static assets
│       ├── css/             # Stylesheets
│       │   ├── main.css
│       │   ├── auth.css
│       │   ├── admin.css
│       │   ├── staff.css
│       │   └── billing.css
│       └── js/              # JavaScript modules
│           ├── common/
│           ├── firebase/
│           ├── admin/
│           ├── staff/
│           └── main.js
├── vercel.json              # Vercel deployment config
├── README.md
└── .gitignore
```

## User Roles

| Role | Access |
|------|--------|
| Admin | Full system access |
| Staff | Billing, Customers, Dues |
| Customer | View profile and history |

## First Admin Account

After setup, create the first admin account:
1. Go to /register.html
2. Create account with any role
3. Go to Firebase Console > Firestore > users collection
4. Find your user document and change `role` to `ADMIN`
5. Login again to access admin features

## License

This project is created for academic purposes.
